# 🔄 Backend Changes to Support Frontend API Format

## ✅ Changes Made to Backend

### 1. **Field Transformation Middleware** ✨

**File Created:** `src/middleware/fieldTransformer.middleware.ts`

**Purpose:** Automatically transforms frontend field names to backend database schema

**Supported Transformations:**

| Frontend Sends            | Backend Receives                    | Type                                   |
| ------------------------- | ----------------------------------- | -------------------------------------- |
| `firstName`               | `full_name`                         | String mapping                         |
| `surName`                 | `surname`                           | String mapping                         |
| `phone`                   | `mobile_number`                     | String mapping + cleanup (+91 removal) |
| `workType: "experienced"` | `experienced: true, fresher: false` | String → Boolean                       |
| `workType: "fresher"`     | `experienced: false, fresher: true` | String → Boolean                       |
| `experiences[]`           | `work_experience[]`                 | Array mapping                          |
| `skillsList[]`            | `skills[]`                          | Array mapping                          |
| `educationList[]`         | `education[]`                       | Array mapping                          |
| `availabilityJobCategory` | `job_category`                      | String mapping                         |
| `availabilityCategory`    | `interview_availability`            | String mapping                         |
| `expectedSalaryRange`     | `expected_salary`                   | String mapping                         |
| `joiningDate`             | `availability_start`                | String mapping                         |

**Experience Object Transformation:**

```javascript
// Frontend sends:
{
  position: "Developer",
  company: "Tech Corp",
  noticePeriod: "30 days",
  startDate: "2020-01-15",
  endDate: "2023-12-31",
  stillWorkingDate: "2020-01-15"
}

// Backend receives:
{
  position: "Developer",
  company: "Tech Corp",
  salary_period: "30 days",  // noticePeriod → salary_period
  start_date: "2020-01-15",  // startDate → start_date
  end_date: "2023-12-31",    // endDate → end_date
  is_current: false           // Calculated from endDate
}
```

**Skills Object Transformation:**

```javascript
// Frontend sends:
{
  name: "JavaScript",
  level: "Expert",  // This field is ignored
  years: "5"
}

// Backend receives:
{
  skill_name: "JavaScript",      // name → skill_name
  years_of_experience: "5"       // years → years_of_experience
}
```

---

### 2. **Applied Middleware to Routes**

**File Modified:** `src/modules/candidate/candidateProfile.routes.ts`

**Changes:**

```typescript
// Added import
import { transformFrontendFields } from "../../middleware/fieldTransformer.middleware";

// Applied to POST and PUT routes
router.post(
  "/",
  transformFrontendFields,
  validateCandidateProfile,
  checkValidation,
  candidateController.createProfile
);
router.put(
  "/:id",
  validateUUID,
  transformFrontendFields,
  validateCandidateProfile,
  checkValidation,
  candidateController.updateProfile
);
```

**Effect:** All incoming requests are automatically transformed before validation

---

### 3. **Added /resume Alias Endpoint**

**File Modified:** `src/routes/index.ts`

**Changes:**

```typescript
// Candidate profile routes
router.use("/candidate-profile", candidateProfileRoutes);

// ✅ NEW: Alias for frontend compatibility
router.use("/resume", candidateProfileRoutes);
```

**Effect:** Frontend can call either:

- `POST /api/resume` ✅ (frontend spec)
- `POST /api/candidate-profile` ✅ (backend spec)

Both work identically!

---

### 4. **Added Standalone Photo Upload**

**File Created:** `src/routes/upload.routes.ts`

**Endpoint:** `POST /api/upload-photo`

**Purpose:** Accept photo uploads BEFORE profile creation (frontend flow)

**Request:**

```javascript
FormData with 'photo' field
```

**Response:**

```json
{
  "success": true,
  "url": "http://localhost:3000/uploads/temp/temp_photo_1703595600000_abc123.jpg",
  "filename": "temp_photo_1703595600000_abc123.jpg"
}
```

**Storage:** Photos stored in `/uploads/temp/` until profile is created

**Features:**

- ✅ 5MB file size limit
- ✅ Accepts JPG, JPEG, PNG, WEBP
- ✅ Background image optimization
- ✅ Returns public URL

---

### 5. **Registered Upload Route**

**File Modified:** `src/routes/index.ts`

**Changes:**

```typescript
import uploadPhotoRoutes from "./upload.routes";

// Standalone photo upload (frontend compatibility)
router.use("/", uploadPhotoRoutes);
```

---

## 📡 Updated API Endpoints

### Now Frontend Can Use EITHER Format:

#### Option 1: Frontend Format (Recommended for Frontend Team)

```javascript
POST /api/resume
{
  "firstName": "John",           // ✅ Works
  "surName": "Doe",             // ✅ Works
  "phone": "+919876543210",     // ✅ Works (strips +91)
  "workType": "experienced",    // ✅ Works (converts to boolean)
  "experiences": [{             // ✅ Works
    "position": "Developer",
    "company": "Tech",
    "noticePeriod": "30 days",
    "startDate": "2020-01-15",
    "endDate": "2023-12-31"
  }],
  "skillsList": [{              // ✅ Works
    "name": "JavaScript",
    "level": "Expert",
    "years": "5"
  }],
  "availabilityJobCategory": "IT & Software",  // ✅ Works
  "expectedSalaryRange": "5 Lakh - 7 Lakh"    // ✅ Works
}
```

#### Option 2: Backend Format (Still Supported)

```javascript
POST /api/candidate-profile
{
  "full_name": "John",          // ✅ Works
  "surname": "Doe",            // ✅ Works
  "mobile_number": "9876543210", // ✅ Works
  "experienced": true,          // ✅ Works
  "fresher": false,            // ✅ Works
  "work_experience": [...],    // ✅ Works
  "skills": [...],             // ✅ Works
  "job_category": "IT & Software",  // ✅ Works
  "expected_salary": "5 Lakh - 7 Lakh"  // ✅ Works
}
```

**Both formats work! The middleware handles the conversion automatically.**

---

## 🎯 Complete Frontend-Compatible Flow

### Step 1: Send OTP

```javascript
POST /api/send-otp
{
  "email": "user@example.com"
}
```

### Step 2: Verify OTP

```javascript
POST /api/verify-otp
{
  "email": "user@example.com",
  "otp": "123456"
}
```

### Step 3: Upload Photo (Optional - before profile)

```javascript
POST /api/upload-photo
FormData: { photo: File }

Response: {
  "success": true,
  "url": "http://localhost:3000/uploads/temp/temp_photo_123.jpg",
  "filename": "temp_photo_123.jpg"
}
```

### Step 4: Create Profile

```javascript
POST /api/resume  // or /api/candidate-profile
{
  "firstName": "John",
  "surName": "Doe",
  "email": "john@example.com",
  "phone": "+919876543210",
  "workType": "experienced",
  "experiences": [...],
  "skillsList": [...],
  "photoUrl": "http://localhost:3000/uploads/temp/temp_photo_123.jpg"  // optional
}

Response: {
  "success": true,
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",  // ✅ UUID returned
    ...
  }
}
```

### Step 5: Upload Photo to Profile (Alternative)

```javascript
POST /api/candidate-profile/550e8400-e29b-41d4-a716-446655440000/upload
FormData: {
  profile_photo: File,
  resume: File
}
```

---

## ✅ What Frontend Gets Now

### 1. **Flexible Field Names**

- Can use `firstName` instead of `full_name`
- Can use `phone` instead of `mobile_number`
- Can use `workType: "experienced"` instead of `experienced: true`

### 2. **Multiple Endpoint Options**

- `/api/resume` (frontend spec) ✅
- `/api/candidate-profile` (backend spec) ✅
- Both work the same!

### 3. **Proper UUID in Response**

```json
{
  "success": true,
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",  // ✅ UUID
    "full_name": "John",
    ...
  }
}
```

### 4. **Standalone Photo Upload**

- `POST /api/upload-photo` now works ✅
- Returns URL immediately
- Can be used before profile creation

### 5. **Backward Compatibility**

- All existing endpoints still work
- Old format still accepted
- No breaking changes

---

## 🔧 Environment Variables

Add to `.env`:

```bash
BASE_URL=http://localhost:3000
```

This is used for generating photo URLs.

---

## 📝 Database Fields Mapping Reference

### Candidate Profile Fields

| Frontend Field         | Backend DB Column | Transformation        |
| ---------------------- | ----------------- | --------------------- |
| firstName              | full_name         | Direct copy           |
| surName                | surname           | Direct copy           |
| email                  | email             | Direct copy           |
| phone                  | mobile_number     | Remove +91 prefix     |
| workType="experienced" | experienced=true  | String to boolean     |
| workType="fresher"     | fresher=true      | String to boolean     |
| address                | address           | Direct copy           |
| state                  | state             | Direct copy           |
| city                   | city              | Direct copy           |
| village                | -                 | Combined into address |
| district               | -                 | Combined into address |
| photoUrl               | profile_photo     | Extract filename      |

### Experience Fields

| Frontend Field | Backend DB Column       |
| -------------- | ----------------------- |
| experiences[]  | work_experience[]       |
| position       | position                |
| company        | company                 |
| noticePeriod   | salary_period           |
| startDate      | start_date              |
| endDate        | end_date                |
| -              | is_current (calculated) |

### Skills Fields

| Frontend Field | Backend DB Column   |
| -------------- | ------------------- |
| skillsList[]   | skills[]            |
| name           | skill_name          |
| level          | - (ignored)         |
| years          | years_of_experience |

---

## ✅ Testing Checklist

- [x] Middleware created and tested
- [x] Routes updated with middleware
- [x] /resume alias added
- [x] /upload-photo endpoint created
- [x] Build successful
- [x] No TypeScript errors
- [x] Backward compatible

---

## 🚀 Frontend Integration Steps

### Frontend developers can now:

1. ✅ Keep using their existing field names (`firstName`, `surName`, etc.)
2. ✅ Call `POST /api/resume` instead of `/api/candidate-profile`
3. ✅ Send `workType: "experienced"` instead of `experienced: true`
4. ✅ Use `POST /api/upload-photo` for standalone uploads
5. ✅ Get UUID in response: `response.data.id`

**No frontend changes required!** The backend now accepts the frontend format.

---

## 📋 Summary

**Files Created:**

1. `src/middleware/fieldTransformer.middleware.ts` - Field transformation logic
2. `src/routes/upload.routes.ts` - Standalone photo upload

**Files Modified:**

1. `src/modules/candidate/candidateProfile.routes.ts` - Added middleware
2. `src/routes/index.ts` - Added /resume alias and upload route

**Total Changes:** 4 files

**Breaking Changes:** None - Fully backward compatible ✅

**Frontend Impact:** Zero - Frontend code works as-is ✅

---

**Last Updated:** December 26, 2025  
**Version:** 1.1.0 (Backend now frontend-compatible)
