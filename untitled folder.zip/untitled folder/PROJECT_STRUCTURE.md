# 📁 Rojgari India Backend - Project Structure

## 🏗️ Directory Structure

```
rojgari-backend/
├── src/
│   ├── config/                     # Configuration files
│   │   ├── database.ts            # Sequelize database configuration
│   │   └── fileUpload.config.ts   # File upload settings (limits, types)
│   │
│   ├── constants/                  # Application constants
│   │   └── candidateProfile.constants.ts  # Messages, status codes, settings
│   │
│   ├── middleware/                 # Express middlewares
│   │   ├── errorHandler.ts        # Global error handler
│   │   ├── notFoundHandler.ts     # 404 handler
│   │   ├── upload.middleware.ts   # Multer file upload configuration
│   │   └── multerError.middleware.ts  # File upload error handler
│   │
│   ├── models/                     # Database models (shared)
│   │   ├── candidateProfile.model.ts     # Candidate profiles table
│   │   ├── workExperience.model.ts       # Work experience table
│   │   └── candidateSkill.model.ts       # Candidate skills table
│   │
│   ├── modules/                    # Feature modules
│   │   ├── candidate/             # Candidate profile module
│   │   │   ├── candidateProfile.controller.ts  # HTTP request handlers
│   │   │   ├── candidateProfile.service.ts     # Business logic
│   │   │   ├── candidateProfile.routes.ts      # Route definitions
│   │   │   ├── candidateTypes.ts              # TypeScript types
│   │   │   └── workExperience.types.ts        # Work experience types
│   │   │
│   │   └── lookup/                # Lookup data module
│   │       ├── lookup.controller.ts   # Country, state, city endpoints
│   │       ├── lookup.service.ts      # Lookup business logic
│   │       ├── lookup.routes.ts       # Lookup route definitions
│   │       └── lookup.types.ts        # Lookup data types
│   │
│   ├── routes/                     # Main route aggregator
│   │   └── index.ts               # Combines all module routes
│   │
│   ├── utils/                      # Utility functions
│   │   ├── serviceHandlerUtil.ts          # Service error wrapper
│   │   ├── imageProcessingUtil.ts         # Image worker management
│   │   └── documentProcessingUtil.ts      # Document worker management
│   │
│   ├── workers/                    # Worker threads for CPU-intensive tasks
│   │   ├── imageProcessor.worker.ts       # Image resize/compress
│   │   └── documentProcessor.worker.ts    # Document validation
│   │
│   └── server.ts                   # Application entry point
│
├── uploads/                        # File storage
│   ├── profile_photo/             # Candidate photos (organized by ID)
│   └── resume/                    # Candidate resumes (organized by ID)
│
├── dist/                          # Compiled JavaScript (production)
│
├── node_modules/                  # Dependencies
│
├── .env                           # Environment variables (not in git)
├── .env.example                   # Environment template
├── .gitignore                     # Git ignore rules
├── package.json                   # Dependencies and scripts
├── tsconfig.json                  # TypeScript configuration
├── eslint.config.mjs              # ESLint configuration (v9 flat config)
├── test-db-connection.js          # Database connection tester
│
└── Documentation (you're here!)
    ├── PROJECT_STRUCTURE.md       # This file - where everything is
    ├── API_DOCUMENTATION.md       # API endpoints with examples
    └── TECH_STACK.md              # Libraries and their purpose

```

## 📂 Module Structure Explained

### **Modular Architecture Pattern**

Each feature module follows this structure:

```
modules/{feature}/
├── {feature}.controller.ts    # HTTP layer - handles requests/responses
├── {feature}.service.ts       # Business logic - database operations
├── {feature}.routes.ts        # Route definitions
└── {feature}.types.ts         # TypeScript interfaces/types
```

**Benefits:**

- ✅ Easy to locate code for specific features
- ✅ Clear separation of concerns (routes → controller → service → model)
- ✅ Easy to add new modules without touching existing code
- ✅ Each module is self-contained and testable

---

## 🔄 Request Flow

```
Client Request
    ↓
Express Server (server.ts)
    ↓
Route Handler (routes/index.ts)
    ↓
Module Route ({module}.routes.ts)
    ↓
Middleware (upload, validation)
    ↓
Controller ({module}.controller.ts)
    ↓
Service ({module}.service.ts)
    ↓
Model (models/{model}.model.ts)
    ↓
Database (MySQL via Sequelize)
    ↓
Response back to Client
```

---

## 📦 Key Directories

### **src/config/**

Configuration files for database, file uploads, and other settings.

- `database.ts` - Sequelize connection, MySQL settings
- `fileUpload.config.ts` - File size limits, allowed types, processing settings

### **src/constants/**

All hardcoded values in one place for easy maintenance.

- Success/error messages
- HTTP status codes
- Pagination defaults
- File processing settings

### **src/middleware/**

Express middleware functions that run before controllers.

- `errorHandler.ts` - Catches all errors and formats responses
- `upload.middleware.ts` - Handles file uploads with Multer
- `multerError.middleware.ts` - Handles file upload errors

### **src/models/**

Sequelize models representing database tables (shared across modules).

- Each model file = one database table
- Defines schema, relationships, validations

### **src/modules/**

Feature modules - each module is a complete feature with its own routes, controllers, services.

- **candidate/** - Candidate profile management (CRUD, file uploads)
- **lookup/** - Lookup data (countries, states, cities)

### **src/workers/**

Worker threads for CPU-intensive operations (non-blocking).

- Run in separate threads to prevent blocking the main event loop
- Used for image processing and document validation

### **src/utils/**

Reusable utility functions.

- Service call wrappers
- Worker thread managers
- Helper functions

---

## 🗄️ Database Tables

### **candidate_profiles**

Main candidate information (26 fields)

- Personal info: name, email, phone, DOB, gender
- Location: address, country, state, city
- Job preferences: position, salary, category, location
- Files: profile_photo, resume
- Status: Active/Inactive

### **candidate_work_experience**

Work history for each candidate

- Foreign key: `candidate_id` → `candidate_profiles.id`
- Fields: position, company, start_date, end_date, salary_period, is_current
- One candidate can have multiple work experiences

### **candidate_skills**

Skills for each candidate

- Foreign key: `candidate_id` → `candidate_profiles.id`
- Fields: skill_name, years_of_experience
- One candidate can have multiple skills

### **Lookup Tables** (existing in database)

- `countries` - Country list
- `states` - State list with country_id
- `cities` - City list with state_id

---

## 🔐 Environment Variables (.env)

```env
# Server
NODE_ENV=development
PORT=3000
BASE_URL=http://localhost:3000

# Database (XAMPP MySQL)
DB_HOST=localhost
DB_PORT=3306
DB_NAME=admin_rojgari
DB_USER=admin_rojgari
DB_PASSWORD=admin@123
DB_DIALECT=mysql

# JWT (for future authentication)
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=24h

# CORS
CORS_ORIGIN=http://localhost:3000
```

---

## 🚀 NPM Scripts

```bash
npm run dev          # Start development server (nodemon + ts-node)
npm run build        # Compile TypeScript to JavaScript
npm start            # Run compiled code (production)
npm run lint         # Check code quality
npm run lint:fix     # Fix linting issues
```

---

## 📝 File Naming Conventions

- **Models**: `{entity}.model.ts` (e.g., candidateProfile.model.ts)
- **Controllers**: `{module}.controller.ts` (e.g., candidateProfile.controller.ts)
- **Services**: `{module}.service.ts` (e.g., candidateProfile.service.ts)
- **Routes**: `{module}.routes.ts` (e.g., candidateProfile.routes.ts)
- **Types**: `{module}.types.ts` or `{module}Types.ts`
- **Middleware**: `{purpose}.middleware.ts` (e.g., upload.middleware.ts)
- **Workers**: `{purpose}.worker.ts` (e.g., imageProcessor.worker.ts)
- **Utils**: `{purpose}Util.ts` (e.g., serviceHandlerUtil.ts)

---

## 🎯 Quick Navigation Guide

**Need to...**

- **Add a new API endpoint?** → Go to `src/modules/{module}/{module}.routes.ts`
- **Change business logic?** → Go to `src/modules/{module}/{module}.service.ts`
- **Modify database schema?** → Go to `src/models/{model}.model.ts`
- **Change error messages?** → Go to `src/constants/{module}.constants.ts`
- **Update file upload limits?** → Go to `src/config/fileUpload.config.ts`
- **Add new middleware?** → Create in `src/middleware/`
- **Add new module?** → Create folder in `src/modules/` with controller, service, routes, types

---

## 📊 Code Organization Principles

1. **Separation of Concerns**: Routes → Controllers → Services → Models
2. **Single Responsibility**: Each file has one clear purpose
3. **DRY (Don't Repeat Yourself)**: Shared code in utils/ and constants/
4. **Modular Design**: Features are self-contained modules
5. **Type Safety**: TypeScript interfaces for all data structures
6. **Error Handling**: Centralized in middleware and service wrappers
7. **Non-Blocking**: CPU-intensive tasks in worker threads

---

## 🔍 Finding Code Quickly

**By Feature:**

- Candidate Profile → `src/modules/candidate/`
- Lookup Data → `src/modules/lookup/`

**By Layer:**

- Routes → `src/routes/` and `src/modules/*/routes.ts`
- Controllers → `src/modules/*/controller.ts`
- Business Logic → `src/modules/*/service.ts`
- Database → `src/models/`

**By Type:**

- Configuration → `src/config/`
- Constants → `src/constants/`
- Middleware → `src/middleware/`
- Utilities → `src/utils/`
- Workers → `src/workers/`

---

**Next:** Check [API_DOCUMENTATION.md](./API_DOCUMENTATION.md) for API endpoints and examples.
