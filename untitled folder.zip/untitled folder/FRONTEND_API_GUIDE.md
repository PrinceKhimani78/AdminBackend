# 🎯 Rojgari India Backend API - Complete Frontend Guide

## 📡 Base URL

```
Development: http://localhost:3000/api
Production: https://api.rojgariindia.com/api
```

---

## 🔐 1. AUTHENTICATION ENDPOINTS

### 1.1 Send OTP to Email

**Endpoint:** `POST /api/send-otp`

**Purpose:** Generate and send a 6-digit OTP to user's email for verification

**Request Headers:**

```json
{
  "Content-Type": "application/json"
}
```

**Request Body:**

```json
{
  "email": "user@example.com"
}
```

**Field Validation:**
| Field | Type | Required | Validation | Description |
|-------|------|----------|------------|-------------|
| email | string | ✅ Yes | Valid email format | User's email address |

**Success Response (200):**

```json
{
  "success": true,
  "message": "OTP sent successfully"
}
```

**Error Response - Invalid Email (400):**

```json
{
  "success": false,
  "error": "Invalid email format"
}
```

**Error Response - Email Send Failed (500):**

```json
{
  "success": false,
  "error": "Failed to send email"
}
```

**Example - JavaScript/React:**

```javascript
const sendOTP = async (email) => {
  const response = await fetch("http://localhost:3000/api/send-otp", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email }),
  });

  const data = await response.json();
  return data;
};

// Usage
sendOTP("user@example.com")
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
```

**Example - cURL:**

```bash
curl -X POST http://localhost:3000/api/send-otp \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com"}'
```

**Backend Implementation Notes:**

- ✅ OTP is 6 digits (100000-999999)
- ✅ OTP stored in memory cache with 10-minute expiry
- ✅ Email sent via SMTP (nodemailer)
- ✅ Rate limiting applied

---

### 1.2 Verify OTP

**Endpoint:** `POST /api/verify-otp`

**Purpose:** Verify the OTP entered by the user

**Request Headers:**

```json
{
  "Content-Type": "application/json"
}
```

**Request Body:**

```json
{
  "email": "user@example.com",
  "otp": "123456"
}
```

**Field Validation:**
| Field | Type | Required | Validation | Description |
|-------|------|----------|------------|-------------|
| email | string | ✅ Yes | Valid email | User's email address |
| otp | string | ✅ Yes | 6 digits | OTP code received via email |

**Success Response (200):**

```json
{
  "success": true,
  "message": "OTP verified successfully"
}
```

**Error Response - Invalid OTP (400):**

```json
{
  "success": false,
  "message": "Invalid OTP"
}
```

**Error Response - Expired OTP (400):**

```json
{
  "success": false,
  "message": "OTP expired"
}
```

**Error Response - Missing Fields (400):**

```json
{
  "success": false,
  "message": "Missing fields"
}
```

**Error Response - Max Attempts (400):**

```json
{
  "success": false,
  "message": "Maximum verification attempts exceeded. Please request a new OTP"
}
```

**Example - JavaScript/React:**

```javascript
const verifyOTP = async (email, otp) => {
  const response = await fetch("http://localhost:3000/api/verify-otp", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, otp }),
  });

  const data = await response.json();
  return data;
};

// Usage
verifyOTP("user@example.com", "123456")
  .then((response) => console.log(response))
  .catch((error) => console.error(error));
```

**Example - cURL:**

```bash
curl -X POST http://localhost:3000/api/verify-otp \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","otp":"123456"}'
```

**Backend Implementation Notes:**

- ✅ OTP expires after 10 minutes
- ✅ Maximum 5 verification attempts per email
- ✅ OTP is deleted after successful verification

---

## 👤 2. CANDIDATE PROFILE ENDPOINTS

### 2.1 Create Candidate Profile

**Endpoint:** `POST /api/candidate-profile`

**Purpose:** Create a new candidate profile with personal information, work experience, and skills

**Request Headers:**

```json
{
  "Content-Type": "application/json"
}
```

**Request Body:**

```json
{
  "full_name": "John",
  "surname": "Doe",
  "email": "john.doe@example.com",
  "mobile_number": "9876543210",
  "gender": "Male",
  "date_of_birth": "1995-05-15",
  "address": "123 Main Street, Satellite, Ahmedabad",
  "country": "India",
  "state": "Gujarat",
  "city": "Ahmedabad",
  "position": "Software Developer",
  "experienced": true,
  "fresher": false,
  "expected_salary": "5 Lakh - 7 Lakh",
  "job_category": "IT & Software",
  "current_location": "Ahmedabad, Gujarat",
  "interview_availability": "Full-Time",
  "availability_start": "2024-02-01",
  "work_experience": [
    {
      "position": "Senior Developer",
      "company": "Tech Corp India",
      "start_date": "2020-01-15",
      "end_date": "2023-12-31",
      "salary_period": "30 days notice",
      "is_current": false
    }
  ],
  "skills": [
    {
      "skill_name": "JavaScript",
      "years_of_experience": "5"
    },
    {
      "skill_name": "React.js",
      "years_of_experience": "4"
    }
  ]
}
```

**Field Validation:**
| Field | Type | Required | Constraints | Description |
|-------|------|----------|-------------|-------------|
| full_name | string | ✅ Yes | Min: 1, Max: 255 | First name |
| surname | string | ❌ No | Max: 255 | Surname/Last name |
| email | string | ✅ Yes | Valid email, Unique | Email address |
| mobile_number | string | ✅ Yes | 10 digits | Mobile number |
| gender | enum | ✅ Yes | Male/Female/Other | Gender |
| date_of_birth | date | ❌ No | YYYY-MM-DD | Date of birth |
| address | text | ❌ No | - | Full address |
| country | string | ❌ No | Max: 100 | Country |
| state | string | ❌ No | Max: 100 | State |
| city | string | ❌ No | Max: 100 | City |
| position | string | ❌ No | Max: 255 | Desired position |
| experienced | boolean | ❌ No | true/false | Is experienced |
| fresher | boolean | ❌ No | true/false | Is fresher |
| expected_salary | string | ❌ No | - | Expected salary range |
| job_category | string | ❌ No | - | Job category |
| current_location | string | ❌ No | - | Current location |
| interview_availability | string | ❌ No | - | Availability type |
| work_experience | array | ❌ No | - | Work experience list |
| skills | array | ❌ No | - | Skills list |

**Success Response (201):**

```json
{
  "success": true,
  "message": "Profile created successfully",
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "John",
    "surname": "Doe",
    "email": "john.doe@example.com",
    "mobile_number": "9876543210",
    "gender": "Male",
    "date_of_birth": "1995-05-15T00:00:00.000Z",
    "address": "123 Main Street, Satellite, Ahmedabad",
    "country": "India",
    "state": "Gujarat",
    "city": "Ahmedabad",
    "position": "Software Developer",
    "experienced": true,
    "fresher": false,
    "expected_salary": "5 Lakh - 7 Lakh",
    "job_category": "IT & Software",
    "current_location": "Ahmedabad, Gujarat",
    "interview_availability": "Full-Time",
    "profile_photo": null,
    "resume": null,
    "status": "Active",
    "created_at": "2024-12-26T10:30:00.000Z",
    "updated_at": "2024-12-26T10:30:00.000Z",
    "work_experience": [
      {
        "id": "650e8400-e29b-41d4-a716-446655440001",
        "candidate_id": "550e8400-e29b-41d4-a716-446655440000",
        "position": "Senior Developer",
        "company": "Tech Corp India",
        "start_date": "2020-01-15T00:00:00.000Z",
        "end_date": "2023-12-31T00:00:00.000Z",
        "salary_period": "30 days notice",
        "is_current": false,
        "created_at": "2024-12-26T10:30:00.000Z"
      }
    ],
    "skills": [
      {
        "id": "750e8400-e29b-41d4-a716-446655440002",
        "candidate_id": "550e8400-e29b-41d4-a716-446655440000",
        "skill_name": "JavaScript",
        "years_of_experience": "5",
        "created_at": "2024-12-26T10:30:00.000Z"
      },
      {
        "id": "750e8400-e29b-41d4-a716-446655440003",
        "candidate_id": "550e8400-e29b-41d4-a716-446655440000",
        "skill_name": "React.js",
        "years_of_experience": "4",
        "created_at": "2024-12-26T10:30:00.000Z"
      }
    ]
  }
}
```

**Error Response - Duplicate Email (409):**

```json
{
  "success": false,
  "message": "Email already exists"
}
```

**Error Response - Validation Error (400):**

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "email",
      "message": "Invalid email format"
    },
    {
      "field": "mobile_number",
      "message": "Mobile number must be 10 digits"
    }
  ]
}
```

**Example - JavaScript/React:**

```javascript
const createProfile = async (profileData) => {
  const response = await fetch("http://localhost:3000/api/candidate-profile", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(profileData),
  });

  const data = await response.json();
  return data;
};

// Usage
const profileData = {
  full_name: "John",
  surname: "Doe",
  email: "john.doe@example.com",
  mobile_number: "9876543210",
  gender: "Male",
  // ... other fields
};

createProfile(profileData)
  .then((response) => {
    console.log("Profile created:", response.data.id);
  })
  .catch((error) => console.error(error));
```

**Example - cURL:**

```bash
curl -X POST http://localhost:3000/api/candidate-profile \
  -H "Content-Type: application/json" \
  -d '{
    "full_name": "John",
    "surname": "Doe",
    "email": "john.doe@example.com",
    "mobile_number": "9876543210",
    "gender": "Male"
  }'
```

---

### 2.2 Upload Photo and Resume

**Endpoint:** `POST /api/candidate-profile/:id/upload`

**Purpose:** Upload profile photo and/or resume to an existing candidate profile

**Request Headers:**

```json
{
  "Content-Type": "multipart/form-data"
}
```

**Request Body (FormData):**

```javascript
const formData = new FormData();
formData.append("profile_photo", photoFile); // File object
formData.append("resume", resumeFile); // File object
```

**File Constraints:**

**Profile Photo:**

- Max file size: 5MB
- Allowed formats: JPG, JPEG, PNG, WEBP
- Recommended dimensions: 400x500 pixels

**Resume:**

- Max file size: 10MB
- Allowed formats: PDF, DOC, DOCX

**Success Response (200):**

```json
{
  "success": true,
  "message": "Both files uploaded successfully",
  "data": {
    "profile_photo": "profile_photo/550e8400-e29b-41d4-a716-446655440000/profile_550e8400_1703595600000.jpg",
    "resume": "resume/550e8400-e29b-41d4-a716-446655440000/resume_550e8400_1703595600000.pdf"
  }
}
```

**Error Response - No File (400):**

```json
{
  "success": false,
  "message": "No file provided"
}
```

**Error Response - Invalid Format (400):**

```json
{
  "success": false,
  "error": "Only JPG, JPEG, PNG, WEBP files are allowed for profile photo"
}
```

**Error Response - File Too Large (413):**

```json
{
  "success": false,
  "error": "File size exceeds 5MB limit"
}
```

**Error Response - Candidate Not Found (404):**

```json
{
  "success": false,
  "message": "Candidate not found"
}
```

**Example - JavaScript/React:**

```javascript
const uploadFiles = async (candidateId, photoFile, resumeFile) => {
  const formData = new FormData();

  if (photoFile) {
    formData.append("profile_photo", photoFile);
  }

  if (resumeFile) {
    formData.append("resume", resumeFile);
  }

  const response = await fetch(
    `http://localhost:3000/api/candidate-profile/${candidateId}/upload`,
    {
      method: "POST",
      body: formData, // Don't set Content-Type header, browser will set it automatically
    }
  );

  const data = await response.json();
  return data;
};

// Usage with file input
const handleFileUpload = (candidateId) => {
  const photoInput = document.getElementById("photo");
  const resumeInput = document.getElementById("resume");

  const photoFile = photoInput.files[0];
  const resumeFile = resumeInput.files[0];

  uploadFiles(candidateId, photoFile, resumeFile)
    .then((response) => {
      console.log("Files uploaded:", response.data);
    })
    .catch((error) => console.error(error));
};
```

**Example - cURL:**

```bash
curl -X POST http://localhost:3000/api/candidate-profile/550e8400-e29b-41d4-a716-446655440000/upload \
  -F "profile_photo=@/path/to/photo.jpg" \
  -F "resume=@/path/to/resume.pdf"
```

**Backend Implementation Notes:**

- ✅ Files stored in `/uploads/profile_photo/{candidate_id}/` and `/uploads/resume/{candidate_id}/`
- ✅ Virus scanning enabled (ClamAV)
- ✅ Image optimization with Sharp (background processing)
- ✅ Non-blocking file processing using Worker Threads
- ✅ Old files automatically replaced

---

### 2.3 Get All Candidate Profiles

**Endpoint:** `GET /api/candidate-profile`

**Purpose:** Get paginated list of all candidate profiles

**Query Parameters:**
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| page | number | ❌ No | 1 | Page number |
| limit | number | ❌ No | 10 | Items per page (max: 100) |

**Success Response (200):**

```json
{
  "success": true,
  "message": "Profiles retrieved successfully",
  "data": {
    "profiles": [
      {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "full_name": "John",
        "surname": "Doe",
        "email": "john.doe@example.com",
        "mobile_number": "9876543210",
        "gender": "Male",
        "position": "Software Developer",
        "expected_salary": "5 Lakh - 7 Lakh",
        "profile_photo": "profile_photo/550e8400/profile_550e8400_1703595600000.jpg",
        "resume": "resume/550e8400/resume_550e8400_1703595600000.pdf",
        "status": "Active",
        "created_at": "2024-12-26T10:30:00.000Z"
      }
    ],
    "pagination": {
      "current_page": 1,
      "per_page": 10,
      "total": 45,
      "total_pages": 5
    }
  }
}
```

**Example - JavaScript/React:**

```javascript
const getProfiles = async (page = 1, limit = 10) => {
  const response = await fetch(
    `http://localhost:3000/api/candidate-profile?page=${page}&limit=${limit}`
  );

  const data = await response.json();
  return data;
};

// Usage
getProfiles(1, 20).then((response) => {
  console.log("Total profiles:", response.data.pagination.total);
  console.log("Profiles:", response.data.profiles);
});
```

**Example - cURL:**

```bash
curl "http://localhost:3000/api/candidate-profile?page=1&limit=10"
```

---

### 2.4 Get Single Candidate Profile

**Endpoint:** `GET /api/candidate-profile/:id`

**Purpose:** Get detailed information about a specific candidate including work experience and skills

**URL Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | UUID | ✅ Yes | Candidate ID |

**Success Response (200):**

```json
{
  "success": true,
  "message": "Profile retrieved successfully",
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "John",
    "surname": "Doe",
    "email": "john.doe@example.com",
    "mobile_number": "9876543210",
    "gender": "Male",
    "date_of_birth": "1995-05-15T00:00:00.000Z",
    "address": "123 Main Street",
    "country": "India",
    "state": "Gujarat",
    "city": "Ahmedabad",
    "position": "Software Developer",
    "experienced": true,
    "fresher": false,
    "expected_salary": "5 Lakh - 7 Lakh",
    "job_category": "IT & Software",
    "profile_photo": "profile_photo/550e8400/profile.jpg",
    "resume": "resume/550e8400/resume.pdf",
    "status": "Active",
    "created_at": "2024-12-26T10:30:00.000Z",
    "updated_at": "2024-12-26T10:30:00.000Z",
    "work_experience": [
      {
        "id": "650e8400-e29b-41d4-a716-446655440001",
        "position": "Senior Developer",
        "company": "Tech Corp India",
        "start_date": "2020-01-15T00:00:00.000Z",
        "end_date": "2023-12-31T00:00:00.000Z",
        "is_current": false
      }
    ],
    "skills": [
      {
        "id": "750e8400-e29b-41d4-a716-446655440002",
        "skill_name": "JavaScript",
        "years_of_experience": "5"
      }
    ]
  }
}
```

**Error Response - Not Found (404):**

```json
{
  "success": false,
  "message": "Profile not found"
}
```

**Error Response - Invalid ID (400):**

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "id",
      "message": "Invalid UUID format"
    }
  ]
}
```

**Example - JavaScript/React:**

```javascript
const getProfile = async (candidateId) => {
  const response = await fetch(
    `http://localhost:3000/api/candidate-profile/${candidateId}`
  );

  const data = await response.json();
  return data;
};

// Usage
getProfile("550e8400-e29b-41d4-a716-446655440000").then((response) => {
  console.log("Profile:", response.data);
});
```

**Example - cURL:**

```bash
curl http://localhost:3000/api/candidate-profile/550e8400-e29b-41d4-a716-446655440000
```

---

### 2.5 Update Candidate Profile

**Endpoint:** `PUT /api/candidate-profile/:id`

**Purpose:** Update an existing candidate profile

**URL Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | UUID | ✅ Yes | Candidate ID |

**Request Headers:**

```json
{
  "Content-Type": "application/json"
}
```

**Request Body:**

```json
{
  "full_name": "John Updated",
  "position": "Senior Software Developer",
  "expected_salary": "7 Lakh - 10 Lakh",
  "work_experience": [
    {
      "position": "Lead Developer",
      "company": "New Tech Corp",
      "start_date": "2024-01-01",
      "end_date": null,
      "is_current": true,
      "salary_period": "Immediate"
    }
  ]
}
```

**Note:** You can send partial updates (only fields you want to change)

**Success Response (200):**

```json
{
  "success": true,
  "message": "Profile updated successfully",
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "John Updated",
    "position": "Senior Software Developer",
    "expected_salary": "7 Lakh - 10 Lakh"
    // ... other fields
  }
}
```

**Error Response - Not Found (404):**

```json
{
  "success": false,
  "message": "Profile not found"
}
```

**Example - JavaScript/React:**

```javascript
const updateProfile = async (candidateId, updates) => {
  const response = await fetch(
    `http://localhost:3000/api/candidate-profile/${candidateId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updates),
    }
  );

  const data = await response.json();
  return data;
};

// Usage
updateProfile("550e8400-e29b-41d4-a716-446655440000", {
  position: "Senior Developer",
  expected_salary: "7 Lakh - 10 Lakh",
}).then((response) => console.log("Updated:", response.data));
```

---

### 2.6 Delete Candidate Profile

**Endpoint:** `DELETE /api/candidate-profile/:id`

**Purpose:** Delete a candidate profile (cascading delete for related data)

**URL Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | UUID | ✅ Yes | Candidate ID |

**Success Response (200):**

```json
{
  "success": true,
  "message": "Profile deleted successfully",
  "data": null
}
```

**Error Response - Not Found (404):**

```json
{
  "success": false,
  "message": "Profile not found"
}
```

**Example - JavaScript/React:**

```javascript
const deleteProfile = async (candidateId) => {
  const response = await fetch(
    `http://localhost:3000/api/candidate-profile/${candidateId}`,
    {
      method: "DELETE",
    }
  );

  const data = await response.json();
  return data;
};

// Usage
deleteProfile("550e8400-e29b-41d4-a716-446655440000").then((response) =>
  console.log("Deleted:", response.message)
);
```

---

### 2.7 Get Document URLs

**Endpoint:** `GET /api/candidate-profile/:id/documents`

**Purpose:** Get URLs of profile photo and resume for a candidate

**URL Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | UUID | ✅ Yes | Candidate ID |

**Success Response (200):**

```json
{
  "success": true,
  "message": "Documents retrieved successfully",
  "data": {
    "profile_photo": "http://localhost:3000/uploads/profile_photo/550e8400/profile.jpg",
    "resume": "http://localhost:3000/uploads/resume/550e8400/resume.pdf",
    "profile_photo_exists": true,
    "resume_exists": true
  }
}
```

**Error Response - Not Found (404):**

```json
{
  "success": false,
  "message": "Candidate not found"
}
```

**Example - JavaScript/React:**

```javascript
const getDocuments = async (candidateId) => {
  const response = await fetch(
    `http://localhost:3000/api/candidate-profile/${candidateId}/documents`
  );

  const data = await response.json();
  return data;
};

// Usage
getDocuments("550e8400-e29b-41d4-a716-446655440000").then((response) => {
  console.log("Photo URL:", response.data.profile_photo);
  console.log("Resume URL:", response.data.resume);
});
```

---

### 2.8 Download Profile Photo

**Endpoint:** `GET /api/candidate-profile/:id/download/photo`

**Purpose:** Download/stream profile photo

**URL Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | UUID | ✅ Yes | Candidate ID |

**Success Response (200):**

- Content-Type: image/jpeg (or appropriate image type)
- Binary image data (streaming)

**Error Response - Not Found (404):**

```json
{
  "success": false,
  "message": "Photo not found"
}
```

**Example - JavaScript/React:**

```javascript
// Direct usage in <img> tag
<img
  src={`http://localhost:3000/api/candidate-profile/${candidateId}/download/photo`}
  alt="Profile Photo"
/>;

// Or download programmatically
const downloadPhoto = async (candidateId) => {
  const response = await fetch(
    `http://localhost:3000/api/candidate-profile/${candidateId}/download/photo`
  );

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = "profile-photo.jpg";
  a.click();
};
```

---

### 2.9 Download Resume

**Endpoint:** `GET /api/candidate-profile/:id/download/resume`

**Purpose:** Download/stream resume file

**URL Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | UUID | ✅ Yes | Candidate ID |

**Success Response (200):**

- Content-Type: application/pdf (or appropriate document type)
- Binary file data (streaming)

**Error Response - Not Found (404):**

```json
{
  "success": false,
  "message": "Resume not found"
}
```

**Example - JavaScript/React:**

```javascript
const downloadResume = async (candidateId) => {
  const response = await fetch(
    `http://localhost:3000/api/candidate-profile/${candidateId}/download/resume`
  );

  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = "resume.pdf";
  a.click();
};

// Usage
downloadResume("550e8400-e29b-41d4-a716-446655440000");
```

---

## 📋 3. LOOKUP DATA ENDPOINTS

### 3.1 Get Countries

**Endpoint:** `GET /api/lookup/countries`

**Purpose:** Get list of all countries

**Success Response (200):**

```json
{
  "success": true,
  "message": "Countries retrieved successfully",
  "data": [
    {
      "id": "1",
      "name": "India",
      "code": "IN"
    },
    {
      "id": "2",
      "name": "United States",
      "code": "US"
    }
  ]
}
```

**Example - JavaScript/React:**

```javascript
const getCountries = async () => {
  const response = await fetch("http://localhost:3000/api/lookup/countries");
  const data = await response.json();
  return data;
};
```

---

### 3.2 Get States

**Endpoint:** `GET /api/lookup/states`

**Purpose:** Get list of states (optionally filtered by country)

**Query Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| country_id | string | ❌ No | Filter by country ID |

**Success Response (200):**

```json
{
  "success": true,
  "message": "States retrieved successfully",
  "data": [
    {
      "id": "1",
      "name": "Gujarat",
      "country_id": "1"
    },
    {
      "id": "2",
      "name": "Maharashtra",
      "country_id": "1"
    }
  ]
}
```

**Example - JavaScript/React:**

```javascript
const getStates = async (countryId = null) => {
  const url = countryId
    ? `http://localhost:3000/api/lookup/states?country_id=${countryId}`
    : "http://localhost:3000/api/lookup/states";

  const response = await fetch(url);
  const data = await response.json();
  return data;
};
```

---

### 3.3 Get Cities

**Endpoint:** `GET /api/lookup/cities`

**Purpose:** Get list of cities (optionally filtered by state)

**Query Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| state_id | string | ❌ No | Filter by state ID |

**Success Response (200):**

```json
{
  "success": true,
  "message": "Cities retrieved successfully",
  "data": [
    {
      "id": "1",
      "name": "Ahmedabad",
      "state_id": "1"
    },
    {
      "id": "2",
      "name": "Surat",
      "state_id": "1"
    }
  ]
}
```

**Example - JavaScript/React:**

```javascript
const getCities = async (stateId = null) => {
  const url = stateId
    ? `http://localhost:3000/api/lookup/cities?state_id=${stateId}`
    : "http://localhost:3000/api/lookup/cities";

  const response = await fetch(url);
  const data = await response.json();
  return data;
};
```

---

### 3.4 Get Job Functions

**Endpoint:** `GET /api/lookup/job-functions`

**Purpose:** Get list of all job functions/categories

**Success Response (200):**

```json
{
  "success": true,
  "message": "Job functions retrieved successfully",
  "data": [
    {
      "id": "1",
      "name": "IT & Software"
    },
    {
      "id": "2",
      "name": "Marketing"
    },
    {
      "id": "3",
      "name": "Sales"
    }
  ]
}
```

---

### 3.5 Get Job Skills

**Endpoint:** `GET /api/lookup/job-skills`

**Purpose:** Get list of all available job skills

**Success Response (200):**

```json
{
  "success": true,
  "message": "Job skills retrieved successfully",
  "data": [
    {
      "id": "1",
      "name": "JavaScript",
      "category": "Programming"
    },
    {
      "id": "2",
      "name": "React.js",
      "category": "Frontend"
    }
  ]
}
```

---

## 🏥 4. SYSTEM ENDPOINTS

### 4.1 Health Check

**Endpoint:** `GET /api/health`

**Purpose:** Check if API is running

**Success Response (200):**

```json
{
  "success": true,
  "message": "API is running",
  "data": {
    "status": "healthy",
    "timestamp": "2024-12-26T10:30:00.000Z",
    "version": "1.0.0"
  }
}
```

---

## 🔄 COMPLETE FRONTEND FLOW EXAMPLE

### Full Registration Flow

```javascript
// Step 1: Send OTP
const email = "user@example.com";
await fetch("http://localhost:3000/api/send-otp", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ email }),
});

// Step 2: Verify OTP
const otp = "123456"; // User enters this
await fetch("http://localhost:3000/api/verify-otp", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ email, otp }),
});

// Step 3: Create Profile
const profileResponse = await fetch(
  "http://localhost:3000/api/candidate-profile",
  {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      full_name: "John",
      surname: "Doe",
      email: email,
      mobile_number: "9876543210",
      gender: "Male",
      // ... other fields
    }),
  }
);

const profileData = await profileResponse.json();
const candidateId = profileData.data.id;

// Step 4: Upload Photo and Resume
const formData = new FormData();
formData.append("profile_photo", photoFile);
formData.append("resume", resumeFile);

await fetch(
  `http://localhost:3000/api/candidate-profile/${candidateId}/upload`,
  {
    method: "POST",
    body: formData,
  }
);

console.log("Registration complete!");
```

---

## ⚠️ IMPORTANT NOTES FOR FRONTEND

### 1. File Uploads

- ✅ **Always create profile FIRST**, then upload files
- ✅ Use `FormData` for file uploads
- ✅ Don't set `Content-Type` header for multipart requests (browser handles it)
- ✅ Check file size before upload (5MB for photos, 10MB for resumes)

### 2. Email Validation

- ✅ Validate email format on frontend before sending OTP
- ✅ Show 10-minute countdown timer for OTP
- ✅ Limit OTP resend to prevent spam

### 3. Error Handling

- ✅ Always check `response.ok` or `response.status`
- ✅ Parse error messages from `error` or `message` field
- ✅ Display validation errors from `errors` array

### 4. UUIDs

- ✅ Store candidate ID after creation
- ✅ Use UUID format validation: `550e8400-e29b-41d4-a716-446655440000`

### 5. File Access

- ✅ Photo URL: `http://localhost:3000/uploads/profile_photo/{candidate_id}/{filename}`
- ✅ Resume URL: `http://localhost:3000/uploads/resume/{candidate_id}/{filename}`
- ✅ Or use download endpoints for streaming

---

## 🔒 SECURITY FEATURES

- ✅ Rate limiting (100 requests per 15 minutes)
- ✅ Helmet.js security headers
- ✅ CORS protection
- ✅ SQL injection protection
- ✅ File type validation
- ✅ File size validation
- ✅ Virus scanning
- ✅ Input validation (Joi)

---

## 📞 TESTING THE API

Use the provided cURL examples or import the Postman collection:

- File: `Rojgari_Backend_API.postman_collection.json`

---

**Last Updated:** December 26, 2025  
**API Version:** 1.0.0  
**Total Endpoints:** 19

For issues or questions, check the console logs or contact the backend team.
