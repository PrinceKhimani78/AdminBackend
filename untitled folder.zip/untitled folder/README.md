# 🚀 Rojgari India Backend API

Production-ready Node.js backend for job portal with candidate profile management, non-blocking file uploads, and streaming downloads.

## ✨ Key Features

- ✅ **Non-Blocking Architecture** - Worker threads for CPU-intensive tasks
- ✅ **Streaming Downloads** - Memory-efficient file serving (64KB chunks)
- ✅ **File Upload System** - Profile photos & resumes with validation
- ✅ **Image Processing** - Auto-resize to 800x800, 85% quality (Sharp)
- ✅ **Email Uniqueness** - Prevents duplicate registrations (409 Conflict)
- ✅ **Cascade Deletes** - Related data cleanup on profile deletion
- ✅ **Transaction Management** - Database consistency guaranteed
- ✅ **TypeScript** - Type-safe development
- ✅ **Express 5** - Latest web framework
- ✅ **Sequelize ORM** - MySQL database operations
- ✅ **Security** - Helmet, CORS, input validation
- ✅ **ESLint** - Strict code quality rules

## 🎯 Live API Status

Server is running at: **http://localhost:3000**

**Health Check:**

```bash
curl http://localhost:3000/api/health
```

**Response:**

```json
{
  "success": true,
  "message": "API is running",
  "data": {
    "status": "healthy",
    "timestamp": "2025-12-14T14:03:50.781Z",
    "version": "1.0.0"
  }
}
```

---

## 📚 Complete Documentation

We have **3 comprehensive guides** to help you understand and use this API:

### 1️⃣ [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md) 📁

**For New Developers** - Understanding the codebase

- 📂 Complete folder structure with explanations
- 🎯 Where to find specific features
- 🏗️ How code is organized (modular architecture)
- 📝 File naming conventions
- 🔍 Quick navigation guide
- 🔄 Request flow diagram

**When to read:** First day on the project, need to find where code lives

---

### 2️⃣ [API_DOCUMENTATION.md](./API_DOCUMENTATION.md) 📡

**API Reference** - Testing and integration

- 🌐 All API endpoints with examples
- 📥 Request/response formats
- 💻 cURL commands for testing
- ❌ Error handling guide
- 📬 Postman collection included (22 endpoints)

**When to read:** Building frontend, testing APIs, integration

---

### 3️⃣ [TECH_STACK.md](./TECH_STACK.md) 🛠️

**Technical Details** - Libraries and architecture

- 📦 Which library is used for what purpose
- 💡 Code examples for each technology
- ⚡ Performance optimizations explained
- 🏛️ Architecture patterns
- 🎓 Learning resources

**When to read:** Understanding technical decisions, learning the stack

---

## 🚀 Quick Start Guide

### Prerequisites

- ✅ Node.js 18+ and npm 9+
- ✅ XAMPP with MySQL
- ✅ Git

### Installation Steps

**1. Navigate to project**

```bash
cd "/Users/kishan/mutant/rojgari backend"
```

**2. Install dependencies**

```bash
npm install
```

**3. Configure environment**

```bash
cp .env.example .env
# .env is already configured with:
# DB_HOST=localhost
# DB_NAME=admin_rojgari
# DB_USER=admin_rojgari
# DB_PASSWORD=admin@123
```

**4. Start XAMPP MySQL**

```bash
sudo /Applications/XAMPP/xamppfiles/xampp startmysql
```

**5. Test database connection**

```bash
node test-db-connection.js
```

**Expected output:**

```
✅ Connected to XAMPP MySQL successfully!
✅ Test query executed successfully
📊 Database Information:
   Current Database: admin_rojgari
   MySQL Version: 10.4.28-MariaDB
📋 Tables in database: 15
```

**6. Start development server**

```bash
npm run dev
```

**Expected output:**

```
🚀 Server running on http://localhost:3000
📝 Environment: development
```

**7. Test the API**

```bash
curl http://localhost:3000/api/health
```

---

## 📦 NPM Scripts

| Command            | Description                                            |
| ------------------ | ------------------------------------------------------ |
| `npm run dev`      | Development mode with auto-restart (nodemon + ts-node) |
| `npm run build`    | Compile TypeScript to JavaScript (dist/)               |
| `npm start`        | Run production build (node dist/server.js)             |
| `npm run lint`     | Check code quality with ESLint                         |
| `npm run lint:fix` | Auto-fix linting issues                                |
| `npm run clean`    | Remove dist/ folder                                    |
| `npm run rebuild`  | Clean + build                                          |

---

## 🗄️ Database Configuration

### Current Setup (XAMPP MySQL)

```env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=admin_rojgari
DB_USER=admin_rojgari
DB_PASSWORD=admin@123
```

### Database Tables

| Table                       | Description                         | Records                |
| --------------------------- | ----------------------------------- | ---------------------- |
| `candidate_profiles`        | Main candidate data (26 fields)     | 7 profiles             |
| `candidate_work_experience` | Work history (FK: candidate_id)     | Multiple per candidate |
| `candidate_skills`          | Candidate skills (FK: candidate_id) | Multiple per candidate |
| `countries`                 | Country lookup data                 | Pre-populated          |
| `states`                    | State lookup data (FK: country_id)  | Pre-populated          |
| `cities`                    | City lookup data (FK: state_id)     | Pre-populated          |

**Note:** Tables already exist with data. No migrations needed.

---

## 🎯 Core API Endpoints

### Candidate Profile Management

| Method | Endpoint                     | Description                       |
| ------ | ---------------------------- | --------------------------------- |
| GET    | `/api/candidate-profile`     | List all profiles (paginated)     |
| GET    | `/api/candidate-profile/:id` | Get single profile with relations |
| POST   | `/api/candidate-profile`     | Create new profile                |
| PUT    | `/api/candidate-profile/:id` | Update profile                    |
| DELETE | `/api/candidate-profile/:id` | Delete profile (cascade)          |

### File Operations

| Method | Endpoint                                     | Description           |
| ------ | -------------------------------------------- | --------------------- |
| POST   | `/api/candidate-profile/:id/upload`          | Upload photo/resume   |
| GET    | `/api/candidate-profile/:id/download/photo`  | Stream profile photo  |
| GET    | `/api/candidate-profile/:id/download/resume` | Stream resume         |
| GET    | `/api/candidate-profile/:id/documents`       | Get document metadata |

### Lookup Data

| Method | Endpoint                          | Description           |
| ------ | --------------------------------- | --------------------- |
| GET    | `/api/lookup/countries`           | Get all countries     |
| GET    | `/api/lookup/states?country_id=1` | Get states by country |
| GET    | `/api/lookup/cities?state_id=1`   | Get cities by state   |

**Full API documentation:** See [API_DOCUMENTATION.md](./API_DOCUMENTATION.md)

---

## 🧪 Testing

### Postman Collection

Import `Rojgari_Backend_API.postman_collection.json` into Postman:

- 22 endpoints organized in 5 folders
- Pre-configured requests with examples
- Test scenarios included

### cURL Examples

**Create Profile:**

```bash
curl -X POST http://localhost:3000/api/candidate-profile \
  -H "Content-Type: application/json" \
  -d '{
    "full_name": "Test User",
    "surname": "Testing",
    "email": "test@example.com",
    "mobile_number": "9999999999",
    "gender": "Male"
  }'
```

**Upload Files:**

```bash
curl -X POST http://localhost:3000/api/candidate-profile/7/upload \
  -F "profile_photo=@photo.jpg" \
  -F "resume=@resume.pdf"
```

**Download Photo:**

```bash
curl http://localhost:3000/api/candidate-profile/7/download/photo --output photo.jpg
```

---

## 🏗️ Architecture Highlights

### Non-Blocking Design

- **Worker Threads:** Image processing runs in separate threads
- **Streaming:** Files streamed in 64KB chunks (memory efficient)
- **Main Thread:** Always responsive to new requests

### Email Uniqueness Handling

```typescript
// Automatic duplicate detection
POST /api/candidate-profile
{
  "email": "existing@example.com"  // Already in database
}

// Response: 409 Conflict
{
  "success": false,
  "message": "Email already exists",
  "status": 409
}
```

### Transaction Management

All database operations use transactions:

- Create profile + work experience + skills (atomic)
- Update operations rollback on error
- Delete operations cascade with transaction

### File Upload Limits

| File Type     | Max Size | Allowed Extensions             |
| ------------- | -------- | ------------------------------ |
| Profile Photo | 5MB      | .jpg, .jpeg, .png, .gif, .webp |
| Resume        | 10MB     | .pdf, .doc, .docx              |

---

## 📁 Project Structure (Quick View)

```
src/
├── config/              # Database & file upload configuration
├── constants/           # Messages, status codes, settings
├── middleware/          # Express middleware (error, upload, validation)
├── models/              # Sequelize models (database tables)
├── modules/             # Feature modules (candidate, lookup)
│   ├── candidate/      # Candidate profile module
│   │   ├── controller  # HTTP request handlers
│   │   ├── service     # Business logic
│   │   ├── routes      # Route definitions
│   │   └── types       # TypeScript interfaces
│   └── lookup/         # Lookup data module
├── routes/              # Main route aggregator
├── utils/               # Reusable utilities
├── workers/             # Worker threads for CPU tasks
└── server.ts            # Application entry point

uploads/                 # File storage
├── profile_photo/      # Organized by candidate ID
└── resume/             # Organized by candidate ID
```

**Detailed structure:** See [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md)

---

## 🔐 Environment Variables

```env
# Server
NODE_ENV=development
PORT=3000
BASE_URL=http://localhost:3000

# Database (XAMPP MySQL)
DB_HOST=localhost
DB_PORT=3306
DB_NAME=admin_rojgari
DB_USER=admin_rojgari
DB_PASSWORD=admin@123
DB_DIALECT=mysql

# JWT (future authentication)
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=24h

# CORS
CORS_ORIGIN=http://localhost:3000
```

---

## 🛠️ Technology Stack (Overview)

| Technology         | Version  | Purpose                |
| ------------------ | -------- | ---------------------- |
| **Node.js**        | 18+      | Runtime environment    |
| **TypeScript**     | 5.9.3    | Type-safe development  |
| **Express**        | 5.2.1    | Web framework          |
| **Sequelize**      | 6.37.7   | ORM for MySQL          |
| **MySQL2**         | 3.15.3   | Database driver        |
| **Multer**         | 2.0.2    | File upload handling   |
| **Sharp**          | 0.34.5   | Image processing       |
| **Worker Threads** | Built-in | Non-blocking CPU tasks |
| **Helmet**         | 8.1.0    | Security headers       |
| **CORS**           | 2.8.5    | Cross-origin requests  |
| **Joi**            | 18.0.2   | Validation             |
| **ESLint**         | 9.39.2   | Code quality           |

**Complete tech stack:** See [TECH_STACK.md](./TECH_STACK.md)

---

## 📊 Performance Characteristics

- **Concurrent Uploads:** Non-blocking (worker threads)
- **Download Speed:** Streaming (no memory buffering)
- **Database:** Connection pooling (max 5 connections)
- **Image Processing:** Runs in separate thread (main thread unaffected)
- **Memory Usage:** Efficient (streaming + worker threads)

---

## 🐛 Troubleshooting

### Database Connection Failed

```bash
# Check if MySQL is running
sudo /Applications/XAMPP/xamppfiles/xampp status

# Start MySQL if stopped
sudo /Applications/XAMPP/xamppfiles/xampp startmysql

# Test connection
node test-db-connection.js
```

### Port 3000 Already in Use

```bash
# Find process using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>
```

### Build Errors

```bash
# Clean and rebuild
npm run rebuild

# Or manually
rm -rf dist node_modules
npm install
npm run build
```

---

## 👥 For New Developers

**Getting Started Checklist:**

1. ✅ Read [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md) - Understand where code lives
2. ✅ Read [API_DOCUMENTATION.md](./API_DOCUMENTATION.md) - Learn API endpoints
3. ✅ Read [TECH_STACK.md](./TECH_STACK.md) - Understand technologies used
4. ✅ Install dependencies: `npm install`
5. ✅ Configure `.env` file with database credentials
6. ✅ Start XAMPP MySQL
7. ✅ Test connection: `node test-db-connection.js`
8. ✅ Start server: `npm run dev`
9. ✅ Test API: `curl http://localhost:3000/api/health`
10. ✅ Import Postman collection and test all endpoints

**Need help?** All three documentation files have detailed explanations and examples.

---

## 📝 Code Quality

- ✅ **TypeScript:** Strict mode enabled
- ✅ **ESLint:** No unused variables, imports, or duplicate declarations
- ✅ **Modular:** Clear separation of concerns
- ✅ **Constants:** No hardcoded values
- ✅ **Error Handling:** Centralized and consistent
- ✅ **Build Status:** 0 errors

---

## 🚀 Production Ready

This backend is production-ready with:

- Non-blocking architecture
- Transaction management
- Email uniqueness validation
- Cascade deletes
- Streaming file downloads
- Worker threads for CPU tasks
- Security middleware
- Error handling
- Type safety
- Comprehensive documentation

---

## 📞 Support

For questions or issues:

- Check documentation files (PROJECT_STRUCTURE, API_DOCUMENTATION, TECH_STACK)
- Review Postman collection for working examples
- Check terminal logs for detailed error messages

---

**Made with ❤️ for Rojgari India**
