# New API Endpoints Implementation# New API Endpoints Implementation

## ✅ All Endpoints Organized Under Logical Routes## ✅ Implemented Endpoints

### Authentication EndpointsAll endpoints from the frontend specification have been implemented:

- `POST /api/send-otp` - Send OTP to email

- `POST /api/verify-otp` - Verify OTP code### 1. **POST `/api/send-otp`**

### Candidate Profile Endpoints- Generates and sends 6-digit OTP to email

- OTP valid for 10 minutes

#### New Resume Submission Flow- Stored in memory cache (node-cache)

- `POST /api/candidate-profile/upload-photo` - Upload photo first (standalone)- Email sent via nodemailer

- `POST /api/candidate-profile/resume` - Submit complete resume with photoUrl

- `POST /api/candidate-profile/resume-with-photo` - **RECOMMENDED** - Submit resume + photo together**Configuration Required:**

Add to `.env`:

#### Existing CRUD Operations

- `GET /api/candidate-profile` - Get all profiles (paginated)```bash

- `GET /api/candidate-profile/:id` - Get single profileSMTP_HOST=smtp.gmail.com

- `POST /api/candidate-profile` - Create profile (existing method)SMTP_PORT=587

- `PUT /api/candidate-profile/:id` - Update profileSMTP_SECURE=false

- `DELETE /api/candidate-profile/:id` - Delete profileSMTP_USER=your-email@gmail.com

SMTP_PASSWORD=your-app-password

#### Document Management```

- `GET /api/candidate-profile/:id/documents` - Get document URLs

- `POST /api/candidate-profile/:id/upload` - Upload to existing profile---

- `GET /api/candidate-profile/:id/download/photo` - Download photo

- `GET /api/candidate-profile/:id/download/resume` - Download resume### 2. **POST `/api/verify-otp`**

---- Verifies OTP against stored value

- Checks expiry (10 minutes)

## 🔄 Two Resume Submission Approaches- Max 5 attempts per email

- Deletes OTP after successful verification

### Approach 1: Two-Step (Matches Frontend Spec)

````---

1. POST /api/candidate-profile/upload-photo

   → Returns: { success: true, url: "http://..." }### 3. **POST `/api/upload-photo`** (Standalone)



2. POST /api/candidate-profile/resume- Uploads photo WITHOUT candidate profile

   Body: { firstName, surName, ..., photoUrl: "http://..." }- Returns publicly accessible URL

   → Returns: { success: true, data: { resumeId: "uuid" } }- Max size: 5MB

```- Allowed formats: JPG, JPEG, PNG, WEBP

⚠️ **Issue:** Orphaned photos if user abandons form- **⚠️ Warning:** Creates orphaned files if user abandons form



### Approach 2: Single Request (RECOMMENDED)---

````

1. POST /api/candidate-profile/resume-with-photo (multipart/form-data)### 4. **POST `/api/resume`** (JSON with photoUrl)

   Fields: firstName, surName, email, ... + photo file

   → Returns: { success: true, data: { resumeId: "uuid" } }- Accepts complete resume data with photoUrl from `/api/upload-photo`

````- Creates candidate profile + experiences/education + skills

✅ **Benefits:** Atomic operation, no orphaned files- Validates based on workType (experienced vs fresher)

- Returns resumeId (candidate ID)

---

---

## 📝 Field Mapping

### 5. **POST `/api/resume-with-photo`** (RECOMMENDED)

The resume endpoints map to existing database schema:

- Accepts multipart/form-data with photo included

| Frontend Field | Database Field |- Everything in ONE request - no orphaned files

|---------------|----------------|- Photo automatically processed and linked

| firstName | full_name |- Returns resumeId

| surName | surname |

| email | email |---

| phone | mobile_number |

| district | city |## 🔄 Two Approaches Available

| photoUrl | profile_photo |

| workType | experienced/fresher |### **Approach 1: Two-Step (Matches Frontend Spec)**

| availabilityJobCategory | job_category/position |

| expectedSalaryRange | expected_salary |```

1. POST /api/upload-photo → Get photoUrl

---2. POST /api/resume (with photoUrl in JSON)

````

## 🔧 Environment Variables Required

**Pros:** Matches frontend spec exactly

Add to `.env`:**Cons:** Orphaned photos if user abandons form

```bash

# Base URL for file serving### **Approach 2: Single Request (RECOMMENDED)**

BASE_URL=http://localhost:3000

```

# SMTP Configuration for OTP emails1. POST /api/resume-with-photo (multipart with all data + photo)

SMTP_HOST=smtp.gmail.com```

SMTP_PORT=587

SMTP_SECURE=false**Pros:** No orphaned files, atomic operation

SMTP_USER=your-email@gmail.com**Cons:** Requires multipart/form-data parsing

SMTP_PASSWORD=your-app-password

````---



**For Gmail:**## 📁 File Structure

1. Enable 2-Factor Authentication

2. Generate App Password: https://myaccount.google.com/apppasswords```

3. Use the app password in `SMTP_PASSWORD`src/

├── modules/

---│   ├── auth/

│   │   ├── otp.types.ts

## 📦 Dependencies Installed│   │   ├── otp.validator.ts

│   │   ├── otp.service.ts

```bash│   │   ├── otp.controller.ts

nodemailer          # Email sending│   │   └── otp.routes.ts

node-cache          # OTP temporary storage│   ├── upload/

@types/nodemailer   # TypeScript types│   │   ├── upload.middleware.ts

@types/node-cache   # TypeScript types│   │   ├── upload.controller.ts

```│   │   └── upload.routes.ts

│   └── resume/

---│       ├── resume.types.ts

│       ├── resume.validator.ts

## ✅ What Was Done│       ├── resume.service.ts

│       ├── resume.controller.ts

1. ✅ Created OTP module (`/api/send-otp`, `/api/verify-otp`)│       └── resume.routes.ts

2. ✅ Created standalone photo upload (`/api/candidate-profile/upload-photo`)```

3. ✅ Created resume submission endpoints (both JSON and multipart)

4. ✅ Added complete Joi validation for all fields---

5. ✅ Organized all routes under `/api/candidate-profile`

6. ✅ Added static file serving for uploads## 🔧 Dependencies Added

7. ✅ Maintained backward compatibility with existing endpoints

```bash

---npm install nodemailer node-cache @types/nodemailer @types/node-cache

````

## 🎯 Recommendation

---

**Use `/api/candidate-profile/resume-with-photo`** for production to avoid orphaned files and ensure data integrity.

## 🚀 Static File Serving

Uploaded files are now publicly accessible via:

```
http://localhost:3000/uploads/profile_photo/{filename}
http://localhost:3000/uploads/resume/{filename}
```

---

## ⚠️ Important Notes

1. **Email Configuration Required:** Must configure SMTP settings in `.env` for OTP functionality
2. **Orphaned Files:** The standalone `/api/upload-photo` can create orphaned files - consider implementing cleanup job
3. **Existing Endpoints Preserved:** All existing `/api/candidate-profile` endpoints still work
4. **Two Flows Available:** Frontend can use either approach based on requirements

---

## 📝 Recommendation

**Use `/api/resume-with-photo` instead of the two-step approach** to avoid orphaned files and ensure atomic operations.
