# 📊 Complete API Endpoints Summary - Rojgari India Backend

## ✅ All Available Endpoints

### 🔐 Authentication

| Method | Endpoint          | Description               | Status     |
| ------ | ----------------- | ------------------------- | ---------- |
| POST   | `/api/send-otp`   | Send 6-digit OTP to email | ✅ Working |
| POST   | `/api/verify-otp` | Verify OTP code           | ✅ Working |

### 👤 Candidate Profile

| Method | Endpoint                                     | Description                       | Status     |
| ------ | -------------------------------------------- | --------------------------------- | ---------- |
| GET    | `/api/candidate-profile`                     | Get all profiles (paginated)      | ✅ Working |
| GET    | `/api/candidate-profile/:id`                 | Get single profile with relations | ✅ Working |
| POST   | `/api/candidate-profile`                     | Create new profile                | ✅ Working |
| PUT    | `/api/candidate-profile/:id`                 | Update existing profile           | ✅ Working |
| DELETE | `/api/candidate-profile/:id`                 | Delete profile                    | ✅ Working |
| GET    | `/api/candidate-profile/:id/documents`       | Get document URLs                 | ✅ Working |
| POST   | `/api/candidate-profile/:id/upload`          | Upload photo/resume to profile    | ✅ Working |
| GET    | `/api/candidate-profile/:id/download/photo`  | Download profile photo            | ✅ Working |
| GET    | `/api/candidate-profile/:id/download/resume` | Download resume                   | ✅ Working |

### 📋 Lookup Data

| Method | Endpoint                          | Description                  | Status     |
| ------ | --------------------------------- | ---------------------------- | ---------- |
| GET    | `/api/lookup/countries`           | Get all countries            | ✅ Working |
| GET    | `/api/lookup/states?country_id=X` | Get states (optional filter) | ✅ Working |
| GET    | `/api/lookup/cities?state_id=X`   | Get cities (optional filter) | ✅ Working |
| GET    | `/api/lookup/job-functions`       | Get all job functions        | ✅ Working |
| GET    | `/api/lookup/job-skills`          | Get all job skills           | ✅ Working |

### 🏥 System

| Method | Endpoint      | Description  | Status     |
| ------ | ------------- | ------------ | ---------- |
| GET    | `/api/health` | Health check | ✅ Working |

---

## 📝 Required from Frontend Specification

### ✅ Implemented

- [x] `POST /api/send-otp` - Send OTP email
- [x] `POST /api/verify-otp` - Verify OTP
- [x] Candidate profile creation flow
- [x] Photo upload (via existing profile upload)
- [x] Complete resume submission

### ❌ Removed (Orphaned File Risk)

- [ ] ~~`POST /api/upload-photo`~~ - Removed to prevent orphaned files
- [ ] ~~`POST /api/resume`~~ - Removed to prevent orphaned files
- [ ] ~~`POST /api/resume-with-photo`~~ - Removed to prevent orphaned files

---

## 🔄 Recommended Frontend Flow

### Step 1: Email Verification

```javascript
// 1. Send OTP
POST /api/send-otp
Body: { email: "user@example.com" }

// 2. Verify OTP
POST /api/verify-otp
Body: { email: "user@example.com", otp: "123456" }
```

### Step 2: Create Profile

```javascript
// 3. Create candidate profile
POST /api/candidate-profile
Body: {
  full_name: "John",
  surname: "Doe",
  email: "john@example.com",
  mobile_number: "9876543210",
  gender: "Male",
  // ... other fields
}
Response: { id: "uuid-123", ... }
```

### Step 3: Upload Files

```javascript
// 4. Upload photo and/or resume
POST /api/candidate-profile/uuid-123/upload
FormData: {
  profile_photo: <File>,
  resume: <File>
}
```

---

## 🔧 Environment Configuration Required

Add to `.env` file:

```bash
# Server
PORT=3000
BASE_URL=http://localhost:3000

# Database
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=rojgari_db

# SMTP for OTP (Gmail example)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password

# CORS
CORS_ORIGIN=http://localhost:3000
```

### Gmail Setup:

1. Enable 2-Factor Authentication
2. Generate App Password: https://myaccount.google.com/apppasswords
3. Use app password in `SMTP_PASSWORD`

---

## 📦 File Upload Specifications

### Profile Photo

- **Max Size:** 5MB
- **Allowed Formats:** JPG, JPEG, PNG, WEBP
- **Recommended:** 400x500 pixels
- **Storage:** `/uploads/profile_photo/{candidate_id}/{filename}`
- **URL:** `http://localhost:3000/uploads/profile_photo/{candidate_id}/{filename}`

### Resume

- **Max Size:** 10MB
- **Allowed Formats:** PDF, DOC, DOCX
- **Storage:** `/uploads/resume/{candidate_id}/{filename}`
- **URL:** `http://localhost:3000/uploads/resume/{candidate_id}/{filename}`

---

## 🔒 Security Features

✅ **Implemented:**

- Helmet.js security headers
- CORS protection
- Rate limiting (100 requests per 15 minutes)
- SQL injection protection (parameterized queries)
- File type validation
- File size validation
- Virus scanning (ClamAV integration)
- Input validation (Joi schemas)
- UUID validation for IDs
- XSS protection

---

## 🎯 Key Differences from Frontend Spec

| Frontend Spec            | Backend Implementation    | Reason                  |
| ------------------------ | ------------------------- | ----------------------- |
| `POST /api/upload-photo` | ❌ Not implemented        | Prevents orphaned files |
| `POST /api/resume`       | ❌ Not implemented        | Prevents orphaned files |
| Photo URL in resume      | Use existing flow instead | Safer architecture      |

**Alternative:** Use `POST /api/candidate-profile` then `POST /api/candidate-profile/:id/upload`

---

## ✅ Testing Checklist

- [ ] Send OTP to email
- [ ] Verify OTP code
- [ ] Create candidate profile
- [ ] Upload photo to profile
- [ ] Upload resume to profile
- [ ] Retrieve profile with documents
- [ ] Download photo
- [ ] Download resume
- [ ] Update profile
- [ ] Delete profile
- [ ] Get lookup data (countries, states, cities)

---

## 📞 Support

For issues or questions:

1. Check API_DOCUMENTATION.md for detailed examples
2. Verify .env configuration
3. Check console logs for errors
4. Ensure database is running and migrated

---

**Last Updated:** December 26, 2025
**Version:** 1.0.0
**Total Endpoints:** 19 working endpoints
