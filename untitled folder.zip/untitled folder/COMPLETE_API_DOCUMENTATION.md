# Rojgari Backend API - Complete Documentation v2.0

## 📋 Table of Contents

1. [Overview](#overview)
2. [Setup & Configuration](#setup--configuration)
3. [Authentication (OTP)](#authentication-otp)
4. [File Upload](#file-upload)
5. [Candidate Profile API](#candidate-profile-api)
6. [Lookup APIs](#lookup-apis)
7. [Field Transformation](#field-transformation)
8. [Error Handling](#error-handling)
9. [Testing Guide](#testing-guide)

---

## Overview

### Base URL

```
Development: http://localhost:5000/api
Production: https://your-domain.com/api
```

### API Version

**v2.0** - Updated with OTP authentication and frontend field support

### Key Features

✅ **OTP-based Authentication** - Email verification with 6-digit OTP  
✅ **Frontend Field Support** - Accepts both frontend and backend field names  
✅ **Automatic Field Transformation** - Backend converts frontend fields automatically  
✅ **File Upload Security** - Virus scanning, size limits, format validation  
✅ **Background Processing** - Image optimization and document processing  
✅ **Backward Compatibility** - Old API format still works

---

## Setup & Configuration

### Environment Variables

Create `.env` file in the project root:

```bash
# Server Configuration
PORT=5000
NODE_ENV=development
BASE_URL=http://localhost:5000

# Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_NAME=rojgari_india
DB_USER=root
DB_PASSWORD=your_password

# Email Configuration (for OTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
EMAIL_FROM=noreply@rojgariindia.com

# File Upload Configuration
MAX_FILE_SIZE=10485760
UPLOAD_DIR=./uploads
ENABLE_VIRUS_SCAN=true

# Security
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100
```

### Installation

```bash
# Install dependencies
npm install

# Run database migrations
npm run migrate

# Seed initial data
npm run seed

# Build TypeScript
npm run build

# Start development server
npm run dev

# Start production server
npm start
```

---

## Authentication (OTP)

### 1. Send OTP

Send a 6-digit OTP to user's email for verification.

**Endpoint:** `POST /api/otp/send-otp`

**Request Body:**

```json
{
  "email": "user@example.com"
}
```

**Response (200 OK):**

```json
{
  "success": true,
  "message": "OTP sent successfully to user@example.com",
  "data": null
}
```

**Features:**

- 6-digit numeric OTP
- 10-minute expiration
- Rate limited: 5 requests per 15 minutes per email
- Secure SMTP email delivery

**Error Responses:**

```json
// Invalid email
{
  "success": false,
  "message": "\"email\" must be a valid email"
}

// Rate limit exceeded
{
  "success": false,
  "message": "Too many OTP requests. Please try again later."
}
```

---

### 2. Verify OTP

Verify the OTP sent to user's email.

**Endpoint:** `POST /api/otp/verify-otp`

**Request Body:**

```json
{
  "email": "user@example.com",
  "otp": "123456"
}
```

**Response (200 OK):**

```json
{
  "success": true,
  "message": "OTP verified successfully",
  "data": {
    "verified": true,
    "email": "user@example.com"
  }
}
```

**Features:**

- Maximum 5 verification attempts
- OTP deleted after successful verification
- Case-insensitive email matching

**Error Responses:**

```json
// Invalid OTP
{
  "success": false,
  "message": "Invalid OTP"
}

// OTP expired
{
  "success": false,
  "message": "OTP has expired. Please request a new one."
}

// Max attempts exceeded
{
  "success": false,
  "message": "Maximum verification attempts exceeded"
}
```

---

## File Upload

### Upload Photo (Temporary)

Upload a photo before creating a candidate profile. Returns temporary URL.

**Endpoint:** `POST /api/upload-photo`

**Request:**

- Content-Type: `multipart/form-data`
- Field name: `photo`

**cURL Example:**

```bash
curl -X POST http://localhost:5000/api/upload-photo \
  -F "photo=@/path/to/photo.jpg"
```

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Photo uploaded successfully",
  "data": {
    "photoUrl": "http://localhost:5000/uploads/temp/temp_photo_1703601234567_abc123.jpg",
    "filename": "temp_photo_1703601234567_abc123.jpg"
  }
}
```

**File Constraints:**

- **Max Size:** 5MB
- **Allowed Formats:** JPG, PNG, WEBP
- **Storage:** Temporary folder (`/uploads/temp/`)
- **Auto Processing:** Background image optimization

**Important Notes:**
⚠️ Temporary files should be moved to permanent storage when profile is created  
⚠️ Include filename in profile creation request (`profilePhoto` field)  
⚠️ Temporary files may be cleaned up periodically

---

## Candidate Profile API

### Field Format Support

The API accepts **BOTH** frontend and backend field formats automatically.

#### Frontend Format (Recommended for Frontend Teams)

```json
{
  "firstName": "Rajesh",
  "surName": "Kumar",
  "phone": "+919876543210",
  "workType": "experienced",
  "experiences": [...],
  "skillsList": [...]
}
```

#### Backend Format (Legacy/Internal)

```json
{
  "full_name": "Rajesh",
  "surname": "Kumar",
  "mobile_number": "9876543210",
  "experienced": true,
  "work_experience": [...],
  "skills": [...]
}
```

**✨ No changes needed in your frontend code!** The backend automatically transforms frontend fields.

---

### 1. Create Candidate Profile

Create a new candidate profile with complete details.

**Endpoint:** `POST /api/candidate-profile`  
**Alias:** `POST /api/resume` (for frontend compatibility)

**Request Body (Frontend Format):**

```json
{
  "firstName": "Rajesh",
  "surName": "Kumar",
  "email": "rajesh.kumar@example.com",
  "phone": "+919876543210",
  "gender": "male",
  "dateOfBirth": "1995-05-15",
  "workType": "experienced",

  "experiences": [
    {
      "position": "Software Engineer",
      "company": "Tech Solutions Pvt Ltd",
      "startDate": "2020-01-15",
      "endDate": "2023-12-31",
      "noticePeriod": "monthly",
      "is_current": false
    }
  ],

  "skillsList": [
    {
      "name": "JavaScript",
      "years": 3
    },
    {
      "name": "React",
      "years": 2
    }
  ],

  "educationList": [
    {
      "degree": "Bachelor of Technology",
      "field_of_study": "Computer Science",
      "institution": "IIT Delhi",
      "graduation_year": 2018
    }
  ],

  "village": "Chandni Chowk",
  "district": "Central Delhi",
  "city": "Delhi",
  "state": "Delhi",
  "pincode": "110006",

  "availabilityJobCategory": "Software Development",
  "availabilityCategory": "immediate",
  "expectedSalaryRange": "8-12 LPA",
  "joiningDate": "2024-02-01",

  "profilePhoto": "temp_photo_1703601234567_abc123.jpg"
}
```

**Response (201 Created):**

```json
{
  "success": true,
  "message": "Candidate profile created successfully",
  "data": {
    "candidate_id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "Rajesh",
    "surname": "Kumar",
    "email": "rajesh.kumar@example.com",
    "mobile_number": "9876543210",
    "gender": "male",
    "date_of_birth": "1995-05-15",
    "experienced": true,
    "fresher": false,
    "profile_photo_url": "http://localhost:5000/uploads/profile_photo/550e8400-e29b-41d4-a716-446655440000.jpg",
    "created_at": "2024-01-01T10:30:00.000Z",
    "updated_at": "2024-01-01T10:30:00.000Z"
  }
}
```

**Field Transformations:**

| Frontend Field            | Backend Field                       | Transformation                         |
| ------------------------- | ----------------------------------- | -------------------------------------- |
| `firstName`               | `full_name`                         | Direct mapping                         |
| `surName`                 | `surname`                           | Direct mapping                         |
| `phone`                   | `mobile_number`                     | Remove +91 prefix, keep last 10 digits |
| `workType: "experienced"` | `experienced: true, fresher: false` | Boolean conversion                     |
| `workType: "fresher"`     | `experienced: false, fresher: true` | Boolean conversion                     |
| `experiences[]`           | `work_experience[]`                 | Array transformation                   |
| `skillsList[]`            | `skills[]`                          | Array transformation                   |
| `educationList[]`         | `education[]`                       | Direct mapping                         |
| `availabilityJobCategory` | `job_category`                      | Direct mapping                         |
| `availabilityCategory`    | `interview_availability`            | Direct mapping                         |
| `expectedSalaryRange`     | `expected_salary`                   | Direct mapping                         |
| `joiningDate`             | `availability_start`                | Direct mapping                         |

---

### 2. Get All Profiles (Paginated)

Retrieve all candidate profiles with pagination.

**Endpoint:** `GET /api/candidate-profile`  
**Alias:** `GET /api/resume`

**Query Parameters:**

- `page` (optional): Page number, default: 1
- `limit` (optional): Items per page, default: 10

**Example:** `GET /api/candidate-profile?page=2&limit=20`

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Candidates retrieved successfully",
  "data": {
    "candidates": [
      {
        "candidate_id": "550e8400-e29b-41d4-a716-446655440000",
        "full_name": "Rajesh",
        "surname": "Kumar",
        "email": "rajesh.kumar@example.com",
        "mobile_number": "9876543210",
        "experienced": true,
        "profile_photo_url": "http://localhost:5000/uploads/profile_photo/550e8400-e29b-41d4-a716-446655440000.jpg"
      }
    ],
    "pagination": {
      "total": 50,
      "page": 2,
      "limit": 20,
      "totalPages": 3
    }
  }
}
```

---

### 3. Get Profile by UUID

Retrieve a single candidate profile with all details.

**Endpoint:** `GET /api/candidate-profile/:id`  
**Alias:** `GET /api/resume/:id`

**Example:** `GET /api/candidate-profile/550e8400-e29b-41d4-a716-446655440000`

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Candidate profile retrieved successfully",
  "data": {
    "candidate_id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "Rajesh",
    "surname": "Kumar",
    "email": "rajesh.kumar@example.com",
    "mobile_number": "9876543210",
    "gender": "male",
    "date_of_birth": "1995-05-15",
    "experienced": true,
    "fresher": false,
    "address": "Chandni Chowk, Central Delhi, Delhi, Delhi",
    "city": "Delhi",
    "state": "Delhi",
    "pincode": "110006",
    "profile_photo_url": "http://localhost:5000/uploads/profile_photo/550e8400-e29b-41d4-a716-446655440000.jpg",
    "resume_url": "http://localhost:5000/uploads/resume/550e8400-e29b-41d4-a716-446655440000.pdf",
    "work_experience": [
      {
        "experience_id": "660e8400-e29b-41d4-a716-446655440001",
        "position": "Software Engineer",
        "company": "Tech Solutions Pvt Ltd",
        "start_date": "2020-01-15",
        "end_date": "2023-12-31",
        "salary_period": "monthly",
        "is_current": false
      }
    ],
    "skills": [
      {
        "skill_id": "770e8400-e29b-41d4-a716-446655440002",
        "skill_name": "JavaScript",
        "years_of_experience": 3
      }
    ],
    "created_at": "2024-01-01T10:30:00.000Z",
    "updated_at": "2024-01-01T10:30:00.000Z"
  }
}
```

---

### 4. Update Profile

Update an existing candidate profile (partial updates allowed).

**Endpoint:** `PUT /api/candidate-profile/:id`

**Request Body (Frontend Format):**

```json
{
  "firstName": "Rajesh Updated",
  "phone": "+919876543299",
  "workType": "fresher",
  "expectedSalaryRange": "10-15 LPA"
}
```

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Candidate profile updated successfully",
  "data": {
    "candidate_id": "550e8400-e29b-41d4-a716-446655440000",
    "full_name": "Rajesh Updated",
    "mobile_number": "9876543299",
    "experienced": false,
    "fresher": true,
    "expected_salary": "10-15 LPA",
    "updated_at": "2024-01-01T11:00:00.000Z"
  }
}
```

---

### 5. Delete Profile

Delete a candidate profile by UUID.

**Endpoint:** `DELETE /api/candidate-profile/:id`

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Candidate profile deleted successfully",
  "data": null
}
```

---

### 6. Upload Profile Photo

Upload or update profile photo for an existing candidate.

**Endpoint:** `POST /api/candidate-profile/:id/photo`

**Request:**

- Content-Type: `multipart/form-data`
- Field name: `profile_photo`

**cURL Example:**

```bash
curl -X POST http://localhost:5000/api/candidate-profile/550e8400-e29b-41d4-a716-446655440000/photo \
  -F "profile_photo=@/path/to/photo.jpg"
```

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Profile photo uploaded successfully",
  "data": {
    "profile_photo_url": "http://localhost:5000/uploads/profile_photo/550e8400-e29b-41d4-a716-446655440000.jpg"
  }
}
```

**File Constraints:**

- **Max Size:** 5MB
- **Allowed Formats:** JPG, PNG, WEBP
- **Auto Processing:** Background optimization (resize, compress, format conversion)
- **Virus Scan:** ClamAV integration (if enabled)

---

### 7. Upload Resume

Upload or update resume for an existing candidate.

**Endpoint:** `POST /api/candidate-profile/:id/resume`

**Request:**

- Content-Type: `multipart/form-data`
- Field name: `resume`

**cURL Example:**

```bash
curl -X POST http://localhost:5000/api/candidate-profile/550e8400-e29b-41d4-a716-446655440000/resume \
  -F "resume=@/path/to/resume.pdf"
```

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Resume uploaded successfully",
  "data": {
    "resume_url": "http://localhost:5000/uploads/resume/550e8400-e29b-41d4-a716-446655440000.pdf"
  }
}
```

**File Constraints:**

- **Max Size:** 10MB
- **Allowed Formats:** PDF, DOC, DOCX
- **Auto Processing:** Background text extraction and indexing
- **Virus Scan:** ClamAV integration (if enabled)

---

### 8. Download Profile Photo

Download candidate's profile photo.

**Endpoint:** `GET /api/candidate-profile/:id/photo`

**Response:** Binary image file (JPG/PNG/WEBP)

**Headers:**

- `Content-Type`: image/jpeg, image/png, or image/webp
- `Content-Disposition`: inline

---

### 9. Download Resume

Download candidate's resume.

**Endpoint:** `GET /api/candidate-profile/:id/resume`

**Response:** Binary document file (PDF/DOC/DOCX)

**Headers:**

- `Content-Type`: application/pdf, application/msword, etc.
- `Content-Disposition`: attachment; filename="resume.pdf"

---

## Lookup APIs

### 1. Get All Countries

**Endpoint:** `GET /api/lookup/countries`

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Countries retrieved successfully",
  "data": [
    {
      "country_id": 1,
      "country_name": "India",
      "country_code": "IN"
    }
  ]
}
```

---

### 2. Get States by Country

**Endpoint:** `GET /api/lookup/states/:countryId`

**Example:** `GET /api/lookup/states/1`

**Response (200 OK):**

```json
{
  "success": true,
  "message": "States retrieved successfully",
  "data": [
    {
      "state_id": 1,
      "state_name": "Delhi",
      "state_code": "DL",
      "country_id": 1
    },
    {
      "state_id": 2,
      "state_name": "Maharashtra",
      "state_code": "MH",
      "country_id": 1
    }
  ]
}
```

---

### 3. Get Cities by State

**Endpoint:** `GET /api/lookup/cities/:stateId`

**Example:** `GET /api/lookup/cities/1`

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Cities retrieved successfully",
  "data": [
    {
      "city_id": 1,
      "city_name": "New Delhi",
      "state_id": 1
    },
    {
      "city_id": 2,
      "city_name": "Delhi",
      "state_id": 1
    }
  ]
}
```

---

### 4. Get All Job Functions

**Endpoint:** `GET /api/lookup/job-functions`

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Job functions retrieved successfully",
  "data": [
    {
      "function_id": 1,
      "function_name": "Software Development",
      "description": "Full stack, backend, frontend development roles"
    },
    {
      "function_id": 2,
      "function_name": "Data Science",
      "description": "ML, AI, data analysis roles"
    }
  ]
}
```

---

## Field Transformation

### How It Works

The backend includes a middleware (`transformFrontendFields`) that automatically converts frontend field names to backend database schema.

**Example Transformation:**

**Frontend Request:**

```json
{
  "firstName": "John",
  "phone": "+919876543210",
  "workType": "experienced"
}
```

**After Transformation (Internal):**

```json
{
  "full_name": "John",
  "mobile_number": "9876543210",
  "experienced": true,
  "fresher": false
}
```

### Supported Transformations

#### Basic Fields

- `firstName` → `full_name`
- `surName` → `surname`
- `phone` → `mobile_number` (with +91 cleanup)
- `dateOfBirth` → `date_of_birth`

#### Work Type

- `workType: "experienced"` → `experienced: true, fresher: false`
- `workType: "fresher"` → `experienced: false, fresher: true`

#### Arrays

- `experiences[]` → `work_experience[]`
- `skillsList[]` → `skills[]`
- `educationList[]` → `education[]`

#### Nested Objects (Experience)

- `startDate` → `start_date`
- `endDate` → `end_date`
- `noticePeriod` → `salary_period`

#### Nested Objects (Skills)

- `name` → `skill_name`
- `years` → `years_of_experience`

#### Availability Fields

- `availabilityJobCategory` → `job_category`
- `availabilityCategory` → `interview_availability`
- `expectedSalaryRange` → `expected_salary`
- `joiningDate` → `availability_start`

#### Address Composition

If `village`, `district`, `city`, `state` are provided separately, they are automatically combined into `address` field.

---

## Error Handling

### Standard Error Response Format

```json
{
  "success": false,
  "message": "Error description",
  "errors": [
    {
      "field": "email",
      "message": "\"email\" must be a valid email"
    }
  ]
}
```

### HTTP Status Codes

| Code | Description                            |
| ---- | -------------------------------------- |
| 200  | Success                                |
| 201  | Created                                |
| 400  | Bad Request (validation error)         |
| 404  | Not Found                              |
| 413  | Payload Too Large (file size exceeded) |
| 429  | Too Many Requests (rate limit)         |
| 500  | Internal Server Error                  |

### Common Error Scenarios

#### Validation Error (400)

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "email",
      "message": "\"email\" is required"
    },
    {
      "field": "phone",
      "message": "\"phone\" must be a valid phone number"
    }
  ]
}
```

#### Not Found (404)

```json
{
  "success": false,
  "message": "Candidate profile not found"
}
```

#### File Too Large (413)

```json
{
  "success": false,
  "message": "File too large. Maximum size is 5MB"
}
```

#### Rate Limit (429)

```json
{
  "success": false,
  "message": "Too many requests. Please try again later."
}
```

---

## Testing Guide

### Using Postman

1. **Import Collection:**

   - Import `Rojgari_Backend_API_Updated.postman_collection.json`
   - Set `base_url` variable to `http://localhost:5000`

2. **Test Flow:**

   ```
   1. Send OTP → Verify OTP
   2. Upload Photo (optional)
   3. Create Profile (captures UUID automatically)
   4. Get Profile by UUID
   5. Upload Resume
   6. Update Profile
   ```

3. **Collection Variables:**
   - `base_url`: Your API base URL
   - `candidate_uuid`: Auto-populated from create profile response

### Using cURL

**Create Profile:**

```bash
curl -X POST http://localhost:5000/api/candidate-profile \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "surName": "User",
    "email": "test@example.com",
    "phone": "+919876543210",
    "workType": "fresher"
  }'
```

**Upload Photo:**

```bash
curl -X POST http://localhost:5000/api/candidate-profile/YOUR_UUID/photo \
  -F "profile_photo=@/path/to/photo.jpg"
```

### Frontend Integration Example (JavaScript/React)

```javascript
// 1. Send OTP
const sendOTP = async (email) => {
  const response = await fetch("http://localhost:5000/api/otp/send-otp", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });
  return response.json();
};

// 2. Verify OTP
const verifyOTP = async (email, otp) => {
  const response = await fetch("http://localhost:5000/api/otp/verify-otp", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, otp }),
  });
  return response.json();
};

// 3. Create Profile (use your exact frontend format!)
const createProfile = async (profileData) => {
  const response = await fetch("http://localhost:5000/api/candidate-profile", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      firstName: profileData.firstName,
      surName: profileData.surName,
      phone: profileData.phone,
      workType: profileData.workType, // "experienced" or "fresher"
      experiences: profileData.experiences,
      skillsList: profileData.skillsList,
      // ... other fields
    }),
  });
  const result = await response.json();
  return result.data.candidate_id; // Save this UUID!
};

// 4. Upload Photo
const uploadPhoto = async (candidateId, photoFile) => {
  const formData = new FormData();
  formData.append("profile_photo", photoFile);

  const response = await fetch(
    `http://localhost:5000/api/candidate-profile/${candidateId}/photo`,
    {
      method: "POST",
      body: formData,
    }
  );
  return response.json();
};
```

---

## Security Features

### 1. Rate Limiting

- **Global:** 100 requests per 15 minutes per IP
- **OTP Send:** 5 requests per 15 minutes per email
- **File Upload:** 10 uploads per 15 minutes per IP

### 2. File Upload Security

- File size validation
- MIME type validation
- Virus scanning (ClamAV integration)
- Filename sanitization
- Storage path validation

### 3. Input Validation

- Joi schema validation
- SQL injection prevention (Sequelize ORM)
- XSS protection (Helmet.js)
- CORS configuration

### 4. Data Protection

- Email validation
- Phone number normalization
- Sensitive data encryption (if configured)

---

## Changelog

### v2.0 (Current)

✅ Added OTP authentication endpoints  
✅ Added field transformation middleware  
✅ Added `/api/upload-photo` standalone endpoint  
✅ Added `/api/resume` alias routes  
✅ Support for both frontend and backend field formats  
✅ Enhanced documentation  
✅ Updated Postman collection

### v1.0

- Initial release with candidate profile CRUD
- File upload/download functionality
- Lookup APIs for countries, states, cities
- Basic validation and error handling

---

## Support & Contact

For questions or issues:

- **Email:** support@rojgariindia.com
- **Documentation:** This file
- **Postman Collection:** `Rojgari_Backend_API_Updated.postman_collection.json`

---

**Last Updated:** December 26, 2024  
**API Version:** 2.0  
**Maintained By:** Rojgari India Backend Team
