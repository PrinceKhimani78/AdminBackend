-- MariaDB dump 10.19  Distrib 10.11.15-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: rojgari_db
-- ------------------------------------------------------
-- Server version	10.11.15-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_settings`
--

DROP TABLE IF EXISTS `admin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_settings`
--

LOCK TABLES `admin_settings` WRITE;
/*!40000 ALTER TABLE `admin_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidate_education`
--

DROP TABLE IF EXISTS `candidate_education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_education` (
  `id` char(36) NOT NULL,
  `candidate_id` char(36) NOT NULL,
  `degree` varchar(255) NOT NULL,
  `university` varchar(255) NOT NULL,
  `passing_year` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate_education`
--

LOCK TABLES `candidate_education` WRITE;
/*!40000 ALTER TABLE `candidate_education` DISABLE KEYS */;
INSERT INTO `candidate_education` VALUES
('19918b33-b77d-47d3-8e6b-d44a3fd6340f','c396f3e6-0bf8-4aa9-9e5b-6e023353ddce','','','','2026-01-23 09:22:09'),
('524e05b3-e117-4db8-9ff8-e2d9bfa9afb6','dd5a7f13-f192-418f-82ca-d6be87f68e2e','','','','2026-01-23 11:10:16'),
('58e0a1df-e9ff-46be-8e68-c7719b24e0b7','7c49f7cb-033e-4e41-a823-38530daa8c39','','','','2026-01-19 11:47:01');
/*!40000 ALTER TABLE `candidate_education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidate_profiles`
--

DROP TABLE IF EXISTS `candidate_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_profiles` (
  `id` char(36) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `alternate_mobile_number` varchar(20) DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `marital_status` varchar(50) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address` text DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `village` varchar(100) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `experienced` tinyint(1) DEFAULT 0,
  `fresher` tinyint(1) DEFAULT 0,
  `expected_salary` varchar(50) DEFAULT NULL,
  `expected_salary_min` int(11) DEFAULT NULL,
  `expected_salary_max` int(11) DEFAULT NULL,
  `total_experience_years` int(11) DEFAULT NULL,
  `job_category` varchar(255) DEFAULT NULL,
  `current_location` varchar(255) DEFAULT NULL,
  `interview_availability` varchar(255) DEFAULT NULL,
  `availability_start` date DEFAULT NULL,
  `availability_end` date DEFAULT NULL,
  `preferred_shift` varchar(50) DEFAULT NULL,
  `profile_photo` varchar(500) DEFAULT NULL,
  `resume` varchar(500) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `summary` text DEFAULT NULL,
  `additional_info` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `idx_candidate_email` (`email`),
  KEY `idx_candidate_mobile` (`mobile_number`),
  KEY `idx_candidate_status` (`status`),
  KEY `idx_candidate_created_at` (`created_at`),
  KEY `idx_candidate_location` (`country`,`state`,`city`),
  KEY `idx_candidate_job_category` (`job_category`),
  KEY `idx_candidate_position` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate_profiles`
--

LOCK TABLES `candidate_profiles` WRITE;
/*!40000 ALTER TABLE `candidate_profiles` DISABLE KEYS */;
INSERT INTO `candidate_profiles` VALUES
('0e279e71-0cfd-4f7a-9989-9d8fb7df1acd','abc','abc','abc@gmail.com','9999999999','NULL','Male','NULL','2001-11-11','abc , abc , abc , morbi','India','Gujarat','Rajkot','Morvi','Morvi','NULL',1,0,'300000 - 5000000',300000,5000000,10,'Nurse','Rajkot, Gujarat','Full-Time','0000-00-00','0000-00-00','NULL','profile_photo/0e279e71-0cfd-4f7a-9989-9d8fb7df1acd/profile_0e279e71-0cfd-4f7a-9989-9d8fb7df1acd_1768058083482.JPG','NULL','103.240.208.210','Active','2026-01-10 15:14:41','2026-01-10 15:14:43','NULL','NULL'),
('0fcd0ced-9fa9-4561-afb0-5a4330c6ab21','areebah 11/01/2026','11/01/2026','areebah@gmail.com','9876543211','NULL','Female','NULL','1999-11-05','sf dfjngkjf vs','India','Gujarat','Rajkot','Rajkot','Sapar Veraval','NULL',1,0,'1023334 - 238749',1023334,238749,5,'Software Developer','Rajkot, Gujarat','Full-Time','0000-00-00','0000-00-00','NULL','profile_photo/0fcd0ced-9fa9-4561-afb0-5a4330c6ab21/profile_0fcd0ced-9fa9-4561-afb0-5a4330c6ab21_1768148718160.jpg','NULL','43.250.156.162','Active','2026-01-11 16:25:17','2026-01-11 16:25:18','NULL','NULL'),
('204fb4e3-7f30-4d37-ad10-df7e6e23dfd9','Priti','chandarana','pritiimutant@gmail.com','7359607557',NULL,'Female','Married','1995-06-08','abc','India','Gujarat','Rajkot','Rajkot','Rajkot',NULL,1,0,'2 - 3',2,3,1,'Web Developer','Rajkot, Gujarat',NULL,'2026-01-29',NULL,'Full-Time','profile_photo/204fb4e3-7f30-4d37-ad10-df7e6e23dfd9/profile_204fb4e3-7f30-4d37-ad10-df7e6e23dfd9_1768825401749.png',NULL,'103.240.208.45','Active','2026-01-19 12:23:21','2026-01-19 12:23:22','ddd','vv'),
('2829c802-b71d-4b6e-a799-54b0d8f0ee3e','areebah','k','areebahkadriwork@gmail.com','9876543210','NULL','Male','NULL','0000-00-00','Rajkot','India','Gujarat','NULL','Rajkot','NULL','NULL',1,0,'5 Lakh - 7 Lakh',0,0,0,'HR Executive','Rajkot, Gujarat','Full-Time','0000-00-00','0000-00-00','NULL','profile_photo/2829c802-b71d-4b6e-a799-54b0d8f0ee3e/profile_2829c802-b71d-4b6e-a799-54b0d8f0ee3e_1767427143242.jpg','NULL','103.240.208.199','Active','2026-01-03 07:59:02','2026-01-03 07:59:03','NULL','NULL'),
('35041fab-4ef7-4aa5-ba27-25a0e87e2713','khushi','desai','khushirojgari@gmail.com','9876543210','NULL','Male','NULL','0000-00-00','acd egfi','India','Gujarat','NULL','Rajkot','NULL','NULL',1,0,'2 Lakh - 3 Lakh',0,0,0,'HR Executive','Ahmadabad, Gujarat','Contract','0000-00-00','0000-00-00','NULL','profile_photo/35041fab-4ef7-4aa5-ba27-25a0e87e2713/profile_35041fab-4ef7-4aa5-ba27-25a0e87e2713_1767428704897.jpg','NULL','103.240.208.199','Active','2026-01-03 08:25:04','2026-01-03 08:25:04','NULL','NULL'),
('3ec51e3e-2ce8-4e22-9e0f-76d9a804ef50','Prince','aa','koxix94120@bablace.com','9090901234','NULL','Male','NULL','2026-01-06','127.0.0.1:5678','India','Gujarat','Rajkot','Rajkot','Rajkot','NULL',1,0,'10 - 20',10,20,1,'Doctor','Andaman & Nicobar Islands, Andaman & Nicobar Islands','Full-Time','0000-00-00','0000-00-00','NULL','profile_photo/3ec51e3e-2ce8-4e22-9e0f-76d9a804ef50/profile_3ec51e3e-2ce8-4e22-9e0f-76d9a804ef50_1768218674864.jpg','NULL','150.129.104.169','Active','2026-01-12 11:51:14','2026-01-12 11:51:14','NULL','NULL'),
('5571b55f-6878-4842-b77a-0d93e7a908a2','prince','khimani','princekhimani187@gmail.com','9327982741','NULL','Male','NULL','0000-00-00','Atladara','India','Gujarat','NULL','Rajkot','NULL','NULL',1,0,'7 Lakh - 10 Lakh',0,0,0,'Tech Support','Rajkot, Gujarat','Contract','0000-00-00','0000-00-00','NULL','profile_photo/5571b55f-6878-4842-b77a-0d93e7a908a2/profile_5571b55f-6878-4842-b77a-0d93e7a908a2_1767095918671.jpg','NULL','::ffff:127.0.0.1','Active','2025-12-30 11:58:38','2025-12-30 11:58:40','NULL','NULL'),
('5952ebed-993d-46d6-8645-a688a808bf13','Devanshi','aa','prince@mutanttechnologies.com','9090901234','NULL','Male','NULL','2026-01-13','a','India','Andaman & Nicobar Islands','Nicobars','Car Nicobar','Metoda','NULL',1,0,'10 - 20',10,20,9,'Doctor','Andaman & Nicobar Islands, Andaman & Nicobar Islands','NULL','2026-01-27','0000-00-00','Full-Time','profile_photo/5952ebed-993d-46d6-8645-a688a808bf13/profile_5952ebed-993d-46d6-8645-a688a808bf13_1768227277234.jpg','NULL','47.11.116.210','Active','2026-01-12 14:14:36','2026-01-12 14:14:37','a',''),
('75bc5d9f-7143-4802-b022-de9d88201ad7','prince','khimani','princekhimani188@gmail.com','9327982741','NULL','Male','NULL','0000-00-00','dfdfgfg','India','Gujarat','NULL','Rajkot','NULL','NULL',1,0,'4 Lakh - 5 Lakh',0,0,0,'Doctors','Rajkot, Gujarat','Internship','0000-00-00','0000-00-00','NULL','NULL','NULL','::ffff:127.0.0.1','Active','2025-12-30 12:51:20','2025-12-30 12:51:20','NULL','NULL'),
('78158099-d719-40ba-b889-5a48b987aba2','Prince','aa','aaaa@gmail.com','9090901234','NULL','Male','NULL','2026-01-03','aaaaa','India','Gujarat','Rajkot','Rajkot','Jetpur','NULL',1,0,'10 - 20',10,20,1,'Pharmacist','Rajkot, Gujarat','Full-Time','0000-00-00','0000-00-00','NULL','profile_photo/78158099-d719-40ba-b889-5a48b987aba2/profile_78158099-d719-40ba-b889-5a48b987aba2_1768058494026.JPG','NULL','103.240.208.210','Active','2026-01-10 15:21:33','2026-01-10 15:21:34','NULL','NULL'),
('7c49f7cb-033e-4e41-a823-38530daa8c39','Hitesh','Desai','adddd@gmail.com','9190909090','919925047780','Male','Single','1119-05-05','403-404 ROJGARI PLACEMENTS PVT.LTD Aadarsh plaza,opp.gujarat gas,150 ft.ring road ,near raiya telephone exchange','India','Gujarat','Gujarat','Gujarat','a',NULL,1,0,'1 - 2',1,2,1,'Doctor',', Gujarat',NULL,'2026-01-20',NULL,'Part-Time','profile_photo/7c49f7cb-033e-4e41-a823-38530daa8c39/profile_7c49f7cb-033e-4e41-a823-38530daa8c39_1768823222236.jpg',NULL,'103.240.208.45','Active','2026-01-19 11:47:01','2026-01-19 11:47:02','aaa',''),
('8d2d2809-71cb-47d1-b734-96783b4257f3','prince','khimani','princekhimani186@gmail.com','8530310001','NULL','Male','NULL','0000-00-00','Atladara','India','Gujarat','NULL','Rajkot','NULL','NULL',0,1,'7 Lakh - 10 Lakh',0,0,0,'IT & Software','Rajkot, Gujarat','Full-Time','0000-00-00','0000-00-00','NULL','NULL','NULL','::ffff:127.0.0.1','Active','2025-12-30 11:10:28','2025-12-30 11:10:28','NULL','NULL'),
('8e112901-9d99-4f66-8681-b8a9e131dd26','kishan','khimani','princekhimani1@gmail.com','9327982741','NULL','Male','NULL','0000-00-00','','India','','NULL','','NULL','NULL',1,0,'2 Lakh - 3 Lakh',0,0,0,'Tech Support','Chandigarh, Chandigarh','Contract','0000-00-00','0000-00-00','NULL','NULL','NULL','::ffff:127.0.0.1','Active','2025-12-30 12:58:55','2025-12-30 12:58:55','NULL','NULL'),
('93c92648-e83b-4818-b44e-83f3ac8e6437','drashti','cchhhh','cdrashti89@gmail.com','9876543210','NULL','Male','NULL','0000-00-00','testingggggg','India','Gujarat','NULL','Jetpur','NULL','NULL',1,0,'2 Lakh - 3 Lakh',0,0,0,'IT & Software','Jetpur, Gujarat','Part-Time','0000-00-00','0000-00-00','NULL','NULL','NULL','150.129.104.143','Active','2025-12-31 17:50:37','2025-12-31 17:50:37','NULL','NULL'),
('9be2c96a-bc37-4e6b-ad1b-46d141fc585a','John','Doe','john.doe1@example.com','9876543210','NULL','Male','NULL','1995-05-15','123 Main Street','India','Maharashtra','NULL','Mumbai','NULL','Software Developer',1,0,'800000',0,0,0,'IT/Software','Mumbai','Immediate','2024-01-01','2024-12-31','Day','NULL','NULL','::ffff:127.0.0.1','Active','2025-12-30 11:05:53','2025-12-30 11:05:53','NULL','NULL'),
('a23010c6-f11e-4d22-a5a0-34e278632cd3','Prince','aa','princekhimani78@gmail.com','9090901234','NULL','Male','NULL','2026-01-02','Address','India','Gujarat','NULL','Rajkot','NULL','NULL',1,0,'10 - 20',0,0,0,'','Rajkot, Gujarat','Full-Time','0000-00-00','0000-00-00','NULL','profile_photo/a23010c6-f11e-4d22-a5a0-34e278632cd3/profile_a23010c6-f11e-4d22-a5a0-34e278632cd3_1768052169443.JPG','NULL','103.240.208.210','Active','2026-01-10 13:36:08','2026-01-10 13:36:09','NULL','NULL'),
('b6900b17-1332-4741-b27f-f35f64e2b08b','prince','khimani','kishanchavda0083@gmail.com','9327982741','NULL','Male','NULL','0000-00-00','Atladara','India','Gujarat','NULL','Rajkot','NULL','NULL',1,0,'7 Lakh - 10 Lakh',0,0,0,'Nurses','Rajkot, Gujarat','Contract','0000-00-00','0000-00-00','NULL','profile_photo/b6900b17-1332-4741-b27f-f35f64e2b08b/profile_b6900b17-1332-4741-b27f-f35f64e2b08b_1767097523155.jpg','NULL','::ffff:127.0.0.1','Active','2025-12-30 12:25:22','2025-12-30 12:25:25','NULL','NULL'),
('c396f3e6-0bf8-4aa9-9e5b-6e023353ddce','Test','Test','ximon51224@mustaer.com','8798765456',NULL,'Male','Single','2026-01-24','test','India','Chhattisgarh','Chhattisgarh','Chhattisgarh','test',NULL,1,0,'1 - 2',1,2,1,'Doctor','Narela, Nct Of Delhi',NULL,'2026-01-24',NULL,'Full-Time','profile_photo/c396f3e6-0bf8-4aa9-9e5b-6e023353ddce/profile_c396f3e6-0bf8-4aa9-9e5b-6e023353ddce_1769160130459.jpg',NULL,'152.59.19.172','Active','2026-01-23 09:22:09','2026-01-23 09:22:10','test','aaa'),
('c5c3e366-679b-412f-825b-4704524138e5','prshant','rathod','prshantrathod@gmail.com','9099099099','NULL','Male','NULL','0000-00-00','na','India','Gujarat','NULL','Rajkot','NULL','NULL',0,1,'7 Lakh - 10 Lakh',0,0,0,'Tech Support','Rajkot, Gujarat','Full-Time','0000-00-00','0000-00-00','NULL','profile_photo/c5c3e366-679b-412f-825b-4704524138e5/profile_c5c3e366-679b-412f-825b-4704524138e5_1767124439516.jpg','NULL','::ffff:127.0.0.1','Active','2025-12-30 19:53:58','2025-12-30 19:54:04','NULL','NULL'),
('d3d3f3d0-c79f-4092-bad4-f0fc815406cd','Devanshi','aa','prince@aa.com','9090901234','919900990099','Male','Married','2026-01-13','a','India','Andaman & Nicobar Islands','Andaman & Nicobar Islands','Andaman & Nicobar Islands','a','NULL',1,0,'10 - 20',10,20,9,'Doctor','Andaman & Nicobar Islands, Andaman & Nicobar Islands','NULL','2026-01-13','0000-00-00','Full-Time','profile_photo/d3d3f3d0-c79f-4092-bad4-f0fc815406cd/profile_d3d3f3d0-c79f-4092-bad4-f0fc815406cd_1768228028233.jpg','NULL','47.11.116.210','Active','2026-01-12 14:27:07','2026-01-12 14:27:08','',''),
('d68a065f-2bd1-48bf-938f-4396c6fe712f','Areebah','Kadri','areebah@areebah.com','9998887766','NULL','Male','NULL','0000-00-00','295 Preston Road','India','Gujarat','NULL','Jetpur','NULL','NULL',0,1,'1 Lakh - 2 Lakh',0,0,0,'Other','Sanguem, Goa','Contract','0000-00-00','0000-00-00','NULL','profile_photo/d68a065f-2bd1-48bf-938f-4396c6fe712f/profile_d68a065f-2bd1-48bf-938f-4396c6fe712f_1767124858173.jpg','NULL','::ffff:127.0.0.1','Active','2025-12-30 20:00:55','2025-12-30 20:00:58','NULL','NULL'),
('dd5a7f13-f192-418f-82ca-d6be87f68e2e','Akshi','Patel','kp384903@gmail.com','7201080009','917201080009','Female','Married','2002-09-16','403/404, Adarsh plaza, Nr. Raiya telephone Exchange','India','Gujarat','Rajkot','Lodhika','metoda',NULL,1,0,'8 - 8',8,8,6,'HR Executive','Rajkot, Gujarat',NULL,'2026-01-23',NULL,'Full-Time','profile_photo/dd5a7f13-f192-418f-82ca-d6be87f68e2e/profile_dd5a7f13-f192-418f-82ca-d6be87f68e2e_1769166616658.png',NULL,'103.240.208.130','Active','2026-01-23 11:10:16','2026-01-23 11:10:16','NA','NA'),
('e4356e97-0ff8-4128-a179-3e459a5a2cad','Hitesh','Desai','personlrojgari@gmail.com','9925047783','NULL','Male','NULL','0000-00-00','403-404 ROJGARI PLACEMENTS PVT.LTD Aadarsh plaza,opp.gujarat gas,150 ft.ring road ,near raiya telephone exchange','India','Gujarat','NULL','Rapar','NULL','NULL',1,0,'',0,0,0,'',', Gujarat','','0000-00-00','0000-00-00','NULL','NULL','NULL','43.250.156.150','Active','2025-12-31 08:08:10','2025-12-31 08:08:10','NULL','NULL'),
('e8beaaa7-6b85-4120-9b6b-7895d1c06662','prince','kh','princekhimani190@gmail.com','9090999099','NULL','Male','NULL','0000-00-00','Atladara','India','Gujarat','NULL','Rajkot','NULL','NULL',1,0,'7 Lakh - 10 Lakh',0,0,0,'Nurses','Dadra & Nagar Haveli, Dadra & Nagar Haveli','Contract','0000-00-00','0000-00-00','NULL','NULL','NULL','43.250.156.150','Active','2025-12-31 11:10:12','2025-12-31 11:10:12','NULL','NULL');
/*!40000 ALTER TABLE `candidate_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidate_skills`
--

DROP TABLE IF EXISTS `candidate_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_skills` (
  `id` char(36) NOT NULL,
  `candidate_id` char(36) NOT NULL,
  `skill_name` varchar(255) NOT NULL,
  `years_of_experience` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_skill_candidate_id` (`candidate_id`),
  KEY `idx_skill_name` (`skill_name`),
  CONSTRAINT `candidate_skills_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `candidate_profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate_skills`
--

LOCK TABLES `candidate_skills` WRITE;
/*!40000 ALTER TABLE `candidate_skills` DISABLE KEYS */;
INSERT INTO `candidate_skills` VALUES
('21ecb7cd-bf74-47c0-911a-74e54b2c1c0e','7c49f7cb-033e-4e41-a823-38530daa8c39','Hitesh Desai',0,'2026-01-19 11:47:01','2026-01-19 11:47:01','Intermediate'),
('6b8ce4a0-057b-47be-890b-c2a4198f92b4','dd5a7f13-f192-418f-82ca-d6be87f68e2e','recruitment',0,'2026-01-23 11:10:16','2026-01-23 11:10:16','Expert'),
('96642425-50a5-4289-b77f-3d20adb21018','c396f3e6-0bf8-4aa9-9e5b-6e023353ddce','skill',0,'2026-01-23 09:22:09','2026-01-23 09:22:09','Intermediate'),
('f5224a16-dff2-4fcd-8654-2a95aca1368a','204fb4e3-7f30-4d37-ad10-df7e6e23dfd9','javascript',0,'2026-01-19 12:23:21','2026-01-19 12:23:21','Intermediate');
/*!40000 ALTER TABLE `candidate_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidate_work_experience`
--

DROP TABLE IF EXISTS `candidate_work_experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate_work_experience` (
  `id` char(36) NOT NULL,
  `candidate_id` char(36) NOT NULL,
  `position` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `salary_period` varchar(50) DEFAULT NULL,
  `current_wages` decimal(12,2) DEFAULT NULL,
  `current_city` varchar(100) DEFAULT NULL,
  `current_village` varchar(100) DEFAULT NULL,
  `is_current` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_work_exp_candidate_id` (`candidate_id`),
  KEY `idx_work_exp_is_current` (`is_current`),
  KEY `idx_work_exp_start_date` (`start_date`),
  CONSTRAINT `candidate_work_experience_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `candidate_profiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate_work_experience`
--

LOCK TABLES `candidate_work_experience` WRITE;
/*!40000 ALTER TABLE `candidate_work_experience` DISABLE KEYS */;
INSERT INTO `candidate_work_experience` VALUES
('0c09e2f6-483c-47ce-8791-0a6a7929e8ee','7c49f7cb-033e-4e41-a823-38530daa8c39','a','Rojgari Placements Pvt. Ltd','2026-01-13','2026-01-20','1',1.00,'Gujarat','a',0,'2026-01-19 11:47:01','2026-01-19 11:47:01'),
('14ea1c21-3cee-4c20-8e14-31d5bb72236a','204fb4e3-7f30-4d37-ad10-df7e6e23dfd9','web developer','mutant','2025-12-16','2026-01-18','1',1.00,'Rajkot','Rajkot',0,'2026-01-19 12:23:21','2026-01-19 12:23:21'),
('1c2cfbf7-422d-48f7-b77a-ffaa3b968039','dd5a7f13-f192-418f-82ca-d6be87f68e2e','HR','Rojgari placements','2022-08-06',NULL,'15',6.00,'Rajkot','Lodhika',1,'2026-01-23 11:10:16','2026-01-23 11:10:16'),
('9ad429c4-0f17-4b8c-91b2-e34920dfee43','dd5a7f13-f192-418f-82ca-d6be87f68e2e','HR','Universal placements','2021-07-14',NULL,'1',6.00,'Rajkot','Lodhika',1,'2026-01-23 11:10:16','2026-01-23 11:10:16'),
('ed3733a9-6d5f-4dcb-9024-3548185479e1','c396f3e6-0bf8-4aa9-9e5b-6e023353ddce','position','name','2026-01-24','2026-01-30','1',1.00,'Chhattisgarh','test',0,'2026-01-23 09:22:09','2026-01-23 09:22:09');
/*!40000 ALTER TABLE `candidate_work_experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gender` enum('Male','Female','Other') NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `experience_year_month` int(3) NOT NULL,
  `education` varchar(255) NOT NULL,
  `job_function_area` int(11) NOT NULL,
  `key_skills` varchar(255) NOT NULL,
  `salary` int(11) NOT NULL,
  `phone_no` varchar(15) NOT NULL,
  `country` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `location` int(11) NOT NULL,
  `resume` longtext NOT NULL,
  `profile_photo` longtext NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `ref_id` int(11) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `email_verfiy_code` varchar(255) NOT NULL,
  `email_code_expire` datetime NOT NULL,
  `email_verified` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidates`
--

LOCK TABLES `candidates` WRITE;
/*!40000 ALTER TABLE `candidates` DISABLE KEYS */;
/*!40000 ALTER TABLE `candidates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cities` (
  `id` char(36) NOT NULL,
  `state_id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_city_state_id` (`state_id`),
  KEY `idx_city_name` (`name`),
  KEY `idx_city_state_name` (`state_id`,`name`),
  CONSTRAINT `cities_ibfk_1` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_inquiry`
--

DROP TABLE IF EXISTS `contact_inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_inquiry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_no` varchar(15) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_inquiry`
--

LOCK TABLES `contact_inquiry` WRITE;
/*!40000 ALTER TABLE `contact_inquiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_inquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_country_name` (`name`),
  KEY `idx_country_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_functions`
--

DROP TABLE IF EXISTS `job_functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_functions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_function_name` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_functions`
--

LOCK TABLES `job_functions` WRITE;
/*!40000 ALTER TABLE `job_functions` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_functions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_industry`
--

DROP TABLE IF EXISTS `job_industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_industry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_industry`
--

LOCK TABLES `job_industry` WRITE;
/*!40000 ALTER TABLE `job_industry` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_posts`
--

DROP TABLE IF EXISTS `job_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_title` longtext NOT NULL,
  `job_location_country` int(11) NOT NULL,
  `job_location_state` int(11) NOT NULL,
  `job_location` int(11) NOT NULL,
  `min_exp` int(11) NOT NULL,
  `max_exp` int(11) NOT NULL,
  `job_type` varchar(25) NOT NULL,
  `education` varchar(100) NOT NULL,
  `min_salary` int(11) NOT NULL,
  `max_salary` int(11) NOT NULL,
  `industry_types` int(11) NOT NULL,
  `job_functions` int(11) NOT NULL,
  `key_skills` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `whatsapp_no` varchar(15) NOT NULL,
  `additional_links` longtext NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_posts`
--

LOCK TABLES `job_posts` WRITE;
/*!40000 ALTER TABLE `job_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_skills`
--

DROP TABLE IF EXISTS `job_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skill_name` longtext NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_skills`
--

LOCK TABLES `job_skills` WRITE;
/*!40000 ALTER TABLE `job_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `states` (
  `id` char(36) NOT NULL,
  `country_id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_state_country_id` (`country_id`),
  KEY `idx_state_name` (`name`),
  KEY `idx_state_country_name` (`country_id`,`name`),
  CONSTRAINT `states_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vw_active_candidates`
--

DROP TABLE IF EXISTS `vw_active_candidates`;
/*!50001 DROP VIEW IF EXISTS `vw_active_candidates`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_active_candidates` AS SELECT
 1 AS `id`,
  1 AS `full_name`,
  1 AS `surname`,
  1 AS `email`,
  1 AS `mobile_number`,
  1 AS `position`,
  1 AS `current_location`,
  1 AS `expected_salary`,
  1 AS `created_at`,
  1 AS `total_experience_count`,
  1 AS `total_skills_count` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `webpages`
--

DROP TABLE IF EXISTS `webpages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webpages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_key` varchar(40) NOT NULL,
  `page_title` varchar(100) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webpages`
--

LOCK TABLES `webpages` WRITE;
/*!40000 ALTER TABLE `webpages` DISABLE KEYS */;
/*!40000 ALTER TABLE `webpages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `vw_active_candidates`
--

/*!50001 DROP VIEW IF EXISTS `vw_active_candidates`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`rojgari_user`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_active_candidates` AS select `cp`.`id` AS `id`,`cp`.`full_name` AS `full_name`,`cp`.`surname` AS `surname`,`cp`.`email` AS `email`,`cp`.`mobile_number` AS `mobile_number`,`cp`.`position` AS `position`,`cp`.`current_location` AS `current_location`,`cp`.`expected_salary` AS `expected_salary`,`cp`.`created_at` AS `created_at`,(select count(0) from `candidate_work_experience` where `candidate_work_experience`.`candidate_id` = `cp`.`id`) AS `total_experience_count`,(select count(0) from `candidate_skills` where `candidate_skills`.`candidate_id` = `cp`.`id`) AS `total_skills_count` from `candidate_profiles` `cp` where `cp`.`status` = 'Active' order by `cp`.`created_at` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-26 11:17:40
